فایل زیپ سورس‌های دقیق نسخه فعلی پیش‌نمایش (دیزاین جدید):

1-home-and-about/ :
   صفحه اصلی جدید (HomePage.tsx بدون بخش حذف‌شده WhySanatPish)، بخش جدید درباره صنعت پیش (HomeAboutSection با تصویر سمت چپ در دسکتاپ، متن بالا و نوار آمار مشکی +5,000 / +24 / +864 / +10,000)، و تمام سکشن‌های صفحه اصلی.

2-forza-workspace-and-popup/ :
   پاپ‌آپ جدید موبایل میزکار FORZA با ژست کشیدن به بالا (AiFloatingButton.tsx + floating-quick-actions.css)، لوگوی جدید FORZA، صفحه کامل میزکار (AiConsultPage.tsx) و کامپوننت‌ها و سرویس‌های میزکار.

3-visual-identification/ :
   کامل بخش شناسایی تصویر قطعه، دوربین، ریسپانسیو موبایل نوار سفارش ساخت (AiVisualPartSearchModal.tsx)، Provider، استایل‌ها، الگوریتم‌های بینایی ماشین (smartPartContour.ts و ...) و روت‌های سروری server.ts.

4-layout-styles-and-assets/ :
   فایل‌های اصلی استایل (index.css, storefront.css, company-pages.css, homepage-refinement.css و ...)، لایوت (Layout, Header, Footer, MobileBottomBar) و تصاویر/آیکن‌های مورد استفاده در دیزاین جدید.