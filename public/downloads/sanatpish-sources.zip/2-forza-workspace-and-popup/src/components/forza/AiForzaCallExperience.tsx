import React, { lazy, Suspense, useCallback, useEffect, useRef, useState } from 'react';
import {
  PhoneOff,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Send,
  MessageSquare,
  Eye,
  Loader2,
  RotateCcw,
  Square,
} from 'lucide-react';
import type { ParticleAvatarProps, ParticleAvatarRef } from './ParticleAvatar';
import { checkpointForzaRecognition, extractPersianSpeechSince, appendForzaSpeechSegment, appendForzaSessionTurn, replaceForzaLastSessionTurn, composeForzaSessionTranscript, mapForzaSegmentsInOrder, forzaEndOfTurnPauseMs, forzaTurnRemainingWaitMs, extractForzaAudioBase64, chooseForzaFinalTranscript } from '../../utils/forzaSpeechPipeline';
import { FORZA_GREETING_TEXT } from '../../utils/forzaGreeting';
import {forzaRecognitionRetryDelay} from '../../utils/forzaRecognitionRecovery';
import { attachForzaAudioEvidence } from '../../utils/forzaAudioEvidence';
import { ForzaSpeechAdmission, ForzaRecognitionAdmission } from '../../utils/forzaSpeechAdmission';
import { ForzaRecordingSafety } from '../../utils/forzaSttTurnSafety';
import { ForzaVoiceActivity, rootMeanSquareFromFloatTimeDomain } from '../../utils/forzaVoiceActivity';
import './style.css';
import { FORZA_DIBA_SAMPLE_RATE, loadDibaSttModel, resampleDibaPcm, type LocalRecognizer, type LocalSttModel } from '../../utils/forzaLocalSpeech';
import { consumeForzaTextStream } from '../../utils/forzaStreamClient';
import { ForzaContinuousWav } from '../../utils/forzaContinuousWav';
import { ForzaNimaBufferedSpeech } from '../../utils/forzaNimaBufferedSpeech';
import { ForzaIncrementalSpeechText } from '../../utils/forzaIncrementalSpeechText';
import { ForzaCallPlainText, forzaSpokenPlainText } from '../../utils/forzaCallPlainText';
import { ForzaStopAcknowledgement } from '../../utils/forzaStopAcknowledgement';
import { ForzaPlaybackEchoHistory, forzaTurnIntent, shouldIgnoreForzaSpeakerEcho } from '../../utils/forzaBargeIn';
import { getForzaAudioContext } from '../../utils/forzaAudioUnlock';
import { FORZA_CONVERSATION_HISTORY_LIMIT, prepareForzaConversationTurn } from '../../utils/forzaConversationHistory';
const AiVisualPartSearchModal = lazy(() => import('../search/AiVisualPartSearchModal').then(module=>({default:module.AiVisualPartSearchModal})));
type LazyParticleAvatarProps = ParticleAvatarProps & { ref?: React.Ref<ParticleAvatarRef> };
const ParticleAvatar = lazy(async () => {
  const module = await import('./ParticleAvatar');
  return {
    default: module.ParticleAvatar as unknown as React.ComponentType<LazyParticleAvatarProps>,
  };
});

interface AiForzaCallExperienceProps {
  onClose?: () => void;
}

type ForzaStatus = 'idle' | 'listening' | 'thinking' | 'speaking';

const GREETING_TEXT = FORZA_GREETING_TEXT;


interface Turn {
  role: 'user' | 'model';
  text: string;
}

function getSupportedAudioMimeType(): string {
  const types = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/ogg;codecs=opus',
    'audio/mp4',
    'audio/aac',
    'audio/wav',
  ];
  for (const t of types) {
    if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t)) {
      return t;
    }
  }
  return 'audio/webm';
}

export const AiForzaCallExperience: React.FC<AiForzaCallExperienceProps> = ({ onClose }) => {
  // Visual scene & humanoid character states
  const callClosedRef = useRef(false);
  const stopAcknowledgementRef=useRef<ForzaStopAcknowledgement|null>(null);
  const voiceModeRef = useRef<'pocket-farsi-v2'|'piper-nima-gyro-medium'|'piper-amir-medium'>('pocket-farsi-v2');
  const voiceInfoPromiseRef=useRef<Promise<void>>(Promise.resolve());
  const [activeVoiceLabel,setActiveVoiceLabel]=useState('در حال بررسی موتور صوتی');
  useEffect(()=>{
    let mounted=true;
    const controller=new AbortController();
    const timeout=window.setTimeout(()=>controller.abort(),2500);
    const task=(async()=>{
      try{
        const response=await fetch('/api/ai/forza-voice-info',{cache:'no-store',signal:controller.signal});
        if(!response.ok)throw new Error('voice_info_http_'+response.status);
        const data=await response.json();
        if(!mounted)return;
        if(data?.voice==='piper-nima-gyro-medium'&&data?.incrementalSpeech===true){
          voiceModeRef.current='piper-nima-gyro-medium';
          setActiveVoiceLabel('نیما (Piper فارسی)');
        }else if(data?.voice==='piper-amir-medium'){
          voiceModeRef.current='piper-amir-medium';
          setActiveVoiceLabel('امیر (Piper فارسی)');
        }else{
          voiceModeRef.current='pocket-farsi-v2';
          setActiveVoiceLabel(data?.voice==='pocket-farsi-v2'
            ?'Pocket TTS فارسی v2':'موتور فعلی سرور');
        }
      }catch{
        if(mounted)setActiveVoiceLabel('موتور فعلی سرور');
      }finally{
        window.clearTimeout(timeout);
      }
    })();
    voiceInfoPromiseRef.current=task;
    return()=>{mounted=false;controller.abort();window.clearTimeout(timeout);};
  },[]);
  const ensureVoiceMode=useCallback(async()=>{
    let timer:number|undefined;
    await Promise.race([
      voiceInfoPromiseRef.current,
      new Promise<void>(resolve=>{timer=window.setTimeout(resolve,2200);}),
    ]);
    if(timer!==undefined)window.clearTimeout(timer);
    return voiceModeRef.current;
  },[]);
  useEffect(() => { callClosedRef.current = false; return () => { callClosedRef.current = true; }; }, []);
  const avatarRef = useRef<ParticleAvatarRef | null>(null);
  const shell = useRef<HTMLDivElement | null>(null);

  const [paused, setPaused] = useState(false);
  const [revision, setRevision] = useState(0);
  const [speed, setSpeed] = useState<number>(2);
  const [clean, setClean] = useState(false);
  // Keep the original high-fidelity silhouette and particle density.
  // Microphone VAD now runs independently of Three.js, so a low render FPS
  // must never silently replace the avatar with a sparse/different design.
  const [quality] = useState<'high'>('high');
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [showImageSearch, setShowImageSearch] = useState(false);
  const [consultationImage,setConsultationImage]=useState('');
  const micMutedBeforeImageSearchRef = useRef(false);
  const imageSearchGenerationRef = useRef(0);
  useEffect(()=>()=>{if(consultationImage.startsWith('blob:'))URL.revokeObjectURL(consultationImage);},[consultationImage]);
  const [showTextInput, setShowTextInput] = useState<boolean>(false);
  const [customInput, setCustomInput] = useState<string>('');
  const [isMicMuted, setIsMicMuted] = useState<boolean>(false);
  const [autoplayBlocked, setAutoplayBlocked] = useState<boolean>(false);
  const [isSpeakerMuted, setIsSpeakerMuted] = useState<boolean>(false);
  const speakerMutedRef=useRef(false);
  const [pendingAudioUrl, setPendingAudioUrl] = useState<string | null>(null);
  const [isUserSpeaking, setIsUserSpeaking] = useState<boolean>(false);
  // The configured provider speaks via STT -> text -> TTS, not Gemini Live WS.
  const [particlesFormed, setParticlesFormed] = useState(false);
  const [greetingPhase, setGreetingPhase] = useState<'forming'|'preparing'|'speaking'|'needs-permission'|'complete'|'error'>('forming');
  const [voicePending, setVoicePending] = useState(false);
  // Distinguish an in-flight LLM from an available WAV and from an
  // AudioContext source actually playing. Never infer sound from text alone.
  const [voiceStage,setVoiceStage]=useState<'idle'|'text'|'synthesizing'|'buffering'|'playing'|'error'>('idle');
  const [voiceWaitSeconds, setVoiceWaitSeconds] = useState(0);
  const greetingStartedRef = useRef(false);
  const micAutoStartedRef = useRef(false);
  const greetingFinishedRef = useRef(false);
  const micMutedRef = useRef(false);
  const speechInterimRef = useRef(false);
  const pendingAudioResolveRef = useRef<(() => void) | null>(null);
  const recognitionFailedRef = useRef(false);
  const recognitionRetryRef=useRef(0);
  const recognitionRetryTimerRef=useRef<number|null>(null);
  const recognitionStartWatchdogRef=useRef<number|null>(null);
  const recognitionStartPendingRef=useRef(false);
  const recognitionStartRef=useRef<()=>void>(()=>{});
  const vadRef = useRef(new ForzaVoiceActivity());
  const speechAdmissionRef=useRef(new ForzaSpeechAdmission());
  const audioEvidenceCleanupRef=useRef<(()=>void)|null>(null);
  const rejectedRecordingRef=useRef(false);
  const micContextWarningRef = useRef(false);
  const lastMicActivityRef = useRef(0);
  const detectedSpeechEndAtRef=useRef(0);
  // Memory-only, non-content latency samples (never transcripts or PCM).
  const endToPlaybackSamplesRef=useRef<number[]>([]);
  const recorderStartedAtRef = useRef(0);
  const speechSegmentStartedRef = useRef(false);
  const localSttModelRef=useRef<LocalSttModel|null>(null);
  const localSttModelLoadingRef=useRef(false);
  const localSttRecognizerRef=useRef<LocalRecognizer|null>(null);
  const localSttAdmissionRef=useRef<ForzaRecognitionAdmission|null>(null);
  const localSttActiveRef=useRef(false);
  const localSttNodeRef=useRef<ScriptProcessorNode|null>(null);
  const localSttSinkRef=useRef<GainNode|null>(null);
  const localSttFinalRef=useRef('');
  const [,setLocalSttStatus]=useState<'loading'|'ready'|'fallback'>('fallback');
  const [microphoneError, setMicrophoneError] = useState<string | null>(null);

  const [stats, setStats] = useState<{ fps: number | null; tier: string; renderMs: number; particles?: number }>({
    fps: null,
    tier: 'ULTRA',
    renderMs: 0,
    particles: 0,
  });
  const [errorNotice, setErrorNotice] = useState<string | null>(null);
  const [voiceOutputError, setVoiceOutputError] = useState<string | null>(null);
  const continuousVoiceRef=useRef<ForzaContinuousWav|null>(null);
  const manualReplayAbortRef=useRef<AbortController|null>(null);
  const isManualReplayPendingRef=useRef(false);
  const [fullscreenError, setFullscreenError] = useState('');
  const [reducedMotion, setReducedMotion] = useState(false);

  // Conversational AI state
  const [isCallActive, setIsCallActive] = useState(true);
  const [status, setStatusState] = useState<ForzaStatus>('idle');
  const [turn, setTurn] = useState<'user' | 'ai' | 'idle'>('ai');
  const [aiText, setAiText] = useState(GREETING_TEXT);
  const [displayedAi, setDisplayedAi] = useState('');
  const [userText, setUserText] = useState('');
  const transcriptCardRef=useRef<HTMLDivElement|null>(null);
  const [seconds, setSeconds] = useState(0);

  const statusRef = useRef<ForzaStatus>('idle');
  const historyRef = useRef<Turn[]>([]);
  const activeTurnRef = useRef<{generation:number; abort:AbortController; markInterrupted?:()=>void}|null>(null);
  const generationRef = useRef(0);
  // Not an authentication credential; a per-page correlation label used for
  // fair rate limits and debugging. No speech, audio or identity is stored.
  const callIdRef=useRef(Math.random().toString(36).slice(2,12));
  const interruptRequestRef = useRef<() => void>(()=>{});
  const isAiSpeakingRef = useRef<boolean>(false);
  const recognitionRef = useRef<any>(null);
  const isRecognitionActiveRef = useRef<boolean>(false);
  const isProcessingTurnRef = useRef<boolean>(false);
  const turnDispatchPendingRef=useRef(false);
  const silenceTimerRef = useRef<number | null>(null);
  const activeTranscriptRef = useRef<string>('');
  // Full in-call customer transcript. Per-turn buffers may close after a reply,
  // but this ledger never loses earlier words when the next phrase arrives.
  const sessionTranscriptRef = useRef<string>('');
  const pendingCommittedTranscriptRef = useRef<string>('');
  const pendingHistoryTurnRef = useRef<string>('');
  const pendingTranscriptRef = useRef<string>('');
  const lastTranscriptChangedAtRef = useRef<number>(0);
  const webSpeechFailedRef = useRef<boolean>(false);
  const recognitionResultCountRef=useRef(0);
  const recognitionConsumedCountRef=useRef(0);
  const recognitionCheckpointRef=useRef({count:0,interim:{} as Record<number,string>});
  const recognitionConsumedInterimRef=useRef<Record<number,string>>({});
  // The browser may restart SpeechRecognition after a pause. Keep the current
  // utterance as the base for the next recognition session instead of losing it.
  const recognitionSessionBaseRef=useRef<string>('');
  // Compare only to speech entering the WebAudio player, not the LLM's
  // unspoken answer. Acoustic echo suppression is NOT diarization.
  const heardSpeechEchoRef=useRef('');
  const lastForzaPlaybackAtRef=useRef(0);
  const playbackEchoHistoryRef=useRef(new ForzaPlaybackEchoHistory());
  const likelySpeakerEcho=(words:string)=>{
    const recentPlayback=isAiSpeakingRef.current ||
      (lastForzaPlaybackAtRef.current>0 && Date.now()-lastForzaPlaybackAtRef.current<1500);
    return shouldIgnoreForzaSpeakerEcho(
      words,heardSpeechEchoRef.current,recentPlayback) || playbackEchoHistoryRef.current.matches(words);
  };
  const serverSttConfiguredRef=useRef(false);
  const [serverSttLabel,setServerSttLabel]=useState('در حال بررسی موتور دایبا...');

  // MediaRecorder audio capture refs (fallback & complementary for STT)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioSegmentsRef = useRef<Blob[]>([]);
  const hasSpeechSoundRef = useRef<boolean>(false);

  const audioElRef = useRef<HTMLAudioElement | null>(null);
  const ctxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const currentBufferSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const audioSourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);
  const micAnalyserRef = useRef<AnalyserNode | null>(null);
  const micSourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const animFrameAudioRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const microphoneGenerationRef = useRef(0);

  const setStatus = useCallback((s: ForzaStatus) => {
    statusRef.current = s;
    setStatusState(s);
  }, []);

  // Download the small offline greeting while the particles form, not after.
  useEffect(() => {
    const audio = new Audio('/forza-greeting-bootstrap.wav');
    audio.preload = 'auto';
    audioElRef.current = audio;
    audio.load();
    return () => {
      audio.pause();
      audio.removeAttribute('src');
      audio.load();
      if (audioElRef.current === audio) audioElRef.current = null;
      };
  }, []);

  // Diba runs in the visitor's browser; no Railway inference.
  const attachLocalStt=useCallback(()=>{
    const ctx=ctxRef.current,source=micSourceNodeRef.current;
    if(!ctx||!source||!localSttModelRef.current||localSttNodeRef.current)return;
    try{
      const node=ctx.createScriptProcessor(2048,1,1),sink=ctx.createGain();
      sink.gain.value=0;
      node.onaudioprocess=(event:AudioProcessingEvent)=>{
        if(micMutedRef.current || !greetingFinishedRef.current ||
           (statusRef.current!=='listening' && !isProcessingTurnRef.current &&
            !isAiSpeakingRef.current && !isManualReplayPendingRef.current))return;
        try{
          const input=event.inputBuffer;
          const mono=input.getChannelData(0);
          const pcm16k=resampleDibaPcm(mono,input.sampleRate);
          if(!pcm16k.length)return;
          const modelBuffer=ctx.createBuffer(1,pcm16k.length,FORZA_DIBA_SAMPLE_RATE);
          modelBuffer.getChannelData(0).set(pcm16k);
          localSttRecognizerRef.current?.acceptWaveform(modelBuffer);
        }catch(error){console.warn('[FORZA Diba] PCM rejected',error);}
      };
      source.connect(node);node.connect(sink);sink.connect(ctx.destination);
      localSttNodeRef.current=node;localSttSinkRef.current=sink;
      setLocalSttStatus('ready');
    }catch(error){console.warn('[FORZA Diba] Audio bridge error',error);setLocalSttStatus('fallback');}
  },[]);

  const startDibaTurn=useCallback(()=>{
    const model=localSttModelRef.current;
    if(!model||!localSttNodeRef.current||!ctxRef.current)return false;
    // Keep one recognizer for the whole call. Recreating it every time the AI
    // finishes a reply used to erase Vosk's finalized words and any speech
    // already arriving during the last milliseconds of playback.
    if(localSttRecognizerRef.current){
      localSttActiveRef.current=true;
      return true;
    }
    try{
      const recognizer=new model.KaldiRecognizer(FORZA_DIBA_SAMPLE_RATE);
      localSttFinalRef.current=activeTranscriptRef.current.trim();
      const admission=new ForzaRecognitionAdmission();
      localSttAdmissionRef.current=admission;
      const update=(value:string,isFinal:boolean)=>{
        if(localSttRecognizerRef.current!==recognizer||micMutedRef.current||
           (statusRef.current!=='listening'&&!isProcessingTurnRef.current &&
            !isAiSpeakingRef.current&&!isManualReplayPendingRef.current))return;
        const words=value.trim();
        const slot={0:{transcript:words},isFinal};
        const playback=isProcessingTurnRef.current||isAiSpeakingRef.current||isManualReplayPendingRef.current;
        const admitted=admission.filter([slot],(text,final)=>likelySpeakerEcho(text)?'reject':
          speechAdmissionRef.current.decide(text,final,playback,Date.now()));
        if(isFinal)admission.reset();
        if(admitted.rejected)rejectedRecordingRef.current=true;
        if(!admitted.changed)return;
        const recognized=extractPersianSpeechSince(admitted.results,0);
        if(isFinal&&recognized.text)
          localSttFinalRef.current=appendForzaSpeechSegment(localSttFinalRef.current,recognized.text);
        const transcript=isFinal
          ?localSttFinalRef.current
          :appendForzaSpeechSegment(localSttFinalRef.current,recognized.text);
        if(!transcript)return;
        if(playback)interruptRequestRef.current();
        if (transcript!==activeTranscriptRef.current || speechInterimRef.current===isFinal) {
          lastTranscriptChangedAtRef.current=Date.now();
        }
        activeTranscriptRef.current=transcript;speechInterimRef.current=!isFinal;
        hasSpeechSoundRef.current=true;
        setUserText(composeForzaSessionTranscript(sessionTranscriptRef.current,transcript));
        setIsUserSpeaking(true);
      };
      recognizer.on('partialresult',msg=>update(String(msg?.result?.partial||''),false));
      recognizer.on('result',msg=>update(String(msg?.result?.text||''),true));
      recognizer.on('error',()=>{
        if(localSttRecognizerRef.current!==recognizer)return;
        localSttRecognizerRef.current=null;
        localSttAdmissionRef.current=null;
        localSttActiveRef.current=false;
        recognizer.remove?.();
        setLocalSttStatus('fallback');
        // If the local WASM recognizer fails, immediately return to the
        // persistent browser recognizer. Its restart handler will run after
        // the current session's onend event.
        if(greetingFinishedRef.current&&!micMutedRef.current){
          recognitionFailedRef.current=false;
          webSpeechFailedRef.current=false;
          recognitionStartRef.current();
        }
      });
      localSttRecognizerRef.current=recognizer;
      localSttActiveRef.current=true;
      return true;
    }catch(error){
      localSttAdmissionRef.current=null;
      localSttActiveRef.current=false;
      console.warn('[FORZA Diba] Recognizer failed',error);
      setLocalSttStatus('fallback');
      return false;
    }
  },[]);
  // Start/Stop voice listening helpers
  const startListening = useCallback((monitorOnly=false) => {
    if (callClosedRef.current || !isCallActive || !greetingFinishedRef.current || micMutedRef.current ||
        (!monitorOnly && (isAiSpeakingRef.current || statusRef.current === 'thinking' || isProcessingTurnRef.current))) {
      return;
    }

    if(!monitorOnly){
      setStatus('listening');
      setTurn('user');
      // Resuming listening must preserve words that arrived as playback ended.
      if (!activeTranscriptRef.current.trim()) {
        lastTranscriptChangedAtRef.current = 0;
        hasSpeechSoundRef.current = false;
        audioChunksRef.current = [];
        audioSegmentsRef.current = [];
        recognitionSessionBaseRef.current='';
      }
    }

    // Prefer the on-device Diba/Vosk partial recognizer once its pinned model
    // is warm. Chrome remains the immediate fallback while that model loads,
    // and is restarted automatically if local recognition fails.
    const localReady=startDibaTurn();
    if(localReady){
      if(recognitionRetryTimerRef.current!==null)window.clearTimeout(recognitionRetryTimerRef.current);
      recognitionRetryTimerRef.current=null;
      if(recognitionStartWatchdogRef.current!==null)window.clearTimeout(recognitionStartWatchdogRef.current);
      recognitionStartWatchdogRef.current=null;
      recognitionStartPendingRef.current=false;
      if(isRecognitionActiveRef.current){
        try{recognitionRef.current?.stop();}catch{}
      }
    }
    if (!localReady && !micMutedRef.current && recognitionRef.current &&
        !isRecognitionActiveRef.current && !recognitionStartPendingRef.current &&
        !recognitionFailedRef.current) {
      // One guarded start path is shared by initial listening and all recovery
      // attempts. A transient InvalidStateError must not strand later turns.
      recognitionStartRef.current();
    }
    const recorder = mediaRecorderRef.current;
    if (!micMutedRef.current && recorder?.state === 'inactive') {
      try {
        audioChunksRef.current = [];
        speechSegmentStartedRef.current = false;
        recorderStartedAtRef.current = Date.now();
        recorder.start(250);
      } catch (error) {
        console.warn('[FORZA] MediaRecorder could not start', (error as any)?.name || 'unavailable');
        setMicrophoneError('ضبط صدا فعال نشد؛ مجوز میکروفون را بررسی کنید.');
      }
    }

    if (silenceTimerRef.current && !activeTranscriptRef.current.trim()) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
  }, [isCallActive, setStatus, startDibaTurn]);

  const stopListening = useCallback(() => {
    localSttRecognizerRef.current?.remove?.();
    localSttRecognizerRef.current=null;
    localSttAdmissionRef.current=null;
    localSttActiveRef.current=false;
    localSttFinalRef.current='';
    if (recognitionRef.current && isRecognitionActiveRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
      isRecognitionActiveRef.current = false;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      try {
        mediaRecorderRef.current.stop();
      } catch {}
    }

    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }

    setIsUserSpeaking(false);
  }, []);

  // Low-latency VAD uses actual mic PCM RMS, not decorative frequency motion.
  // The worker STT fallback receives MediaRecorder audio after a real speech
  // segment finishes; Chrome SpeechRecognition may finish even sooner.
  useEffect(() => {
    let active=true;
    let samples=new Float32Array(512);
    // Mic end-of-turn must not depend on Three.js frames. On weak devices
    // the avatar can fall to 7 FPS while a 55ms audio poll remains active.
    // This timer is not a replacement for a future AudioWorklet VAD:
    // browsers may throttle background-tab timers.
    const check=()=>{
      if(!active)return;
      const evidenceAnalyser=micAnalyserRef.current;
      if(evidenceAnalyser&&streamRef.current?.active&&ctxRef.current?.state==='running'&&!micMutedRef.current){
        if(!audioEvidenceCleanupRef.current){
        if(samples.length!==evidenceAnalyser.fftSize)samples=new Float32Array(evidenceAnalyser.fftSize);
        evidenceAnalyser.getFloatTimeDomainData(samples);
        speechAdmissionRef.current.sample(rootMeanSquareFromFloatTimeDomain(samples),Date.now(),
          isProcessingTurnRef.current||isAiSpeakingRef.current||isManualReplayPendingRef.current);
        }
      }else speechAdmissionRef.current.reset();
      if(!greetingFinishedRef.current || micMutedRef.current ||
         (statusRef.current!=='listening' && !isProcessingTurnRef.current &&
          !isAiSpeakingRef.current&&!isManualReplayPendingRef.current)){
        vadRef.current.reset();
        setAudioLevel(0);
        return;
      }
      const analyser=micAnalyserRef.current;
      if(!analyser || !streamRef.current?.active){
        // WebSpeech may be available without Web Audio; expose real mic
        // readiness rather than pretending to hear any sound.
        setAudioLevel(0);
        return;
      }
      if(ctxRef.current?.state==='suspended'){
        if(!micContextWarningRef.current){
          micContextWarningRef.current=true;
          setMicrophoneError('مرورگر پردازش صدا را متوقف کرده است. برای فعال‌سازی روی «تلاش مجدد میکروفون» بزنید.');
        }
        return;
      }
      try {
        // Float PCM retains quiet speech that byte quantization would erase.
        // Keep the buffer exactly fftSize for both analyser paths.
        if (samples.length !== analyser.fftSize) samples = new Float32Array(analyser.fftSize);
        analyser.getFloatTimeDomainData(samples);
        const rms=rootMeanSquareFromFloatTimeDomain(samples);
        const micNow=Date.now();
        const current=vadRef.current.sample(rms,micNow,
          speechAdmissionRef.current.acousticSpeech||
          speechAdmissionRef.current.hasRecentNearFieldEvidence(micNow));
        // Keep the last near-field VAD timestamp briefly so delayed final STT
        // events survive endpoint reset, while distant/background speech is rejected.
        if(current.speechStarted||current.speaking)lastMicActivityRef.current=micNow;
        setAudioLevel(current.level);
        if(current.speechStarted && speechAdmissionRef.current.acousticSpeech){
          hasSpeechSoundRef.current=true;
          // During TTS this is only a VAD *candidate*. WebSpeech/local STT
          // must provide non-echo words before cancelling the AI response.
          if(!isProcessingTurnRef.current)setIsUserSpeaking(true);
          else console.info('[FORZA_TURN] phase=barge-in-vad-candidate');
        }
        // Keep a 4.2-5.6s continuation window so natural breaths and pauses
        // do not split one customer sentence into separate AI turns.
        if(isProcessingTurnRef.current){
          if(silenceTimerRef.current){clearTimeout(silenceTimerRef.current);silenceTimerRef.current=null;}
          return;
        }
        if(current.speaking&&speechAdmissionRef.current.hasRecentNearFieldEvidence(Date.now())){
          // A resumed syllable can arrive before the 160ms admission latch.
          // Cancel the pending endpoint as soon as fresh near-field PCM returns.
          if(silenceTimerRef.current){
            clearTimeout(silenceTimerRef.current);
            silenceTimerRef.current=null;
          }
        }else if(current.silenceMs>0 && hasSpeechSoundRef.current && !silenceTimerRef.current){
          const transcript=activeTranscriptRef.current.trim();
          const pauseMs=transcript
            ? forzaEndOfTurnPauseMs(transcript,speechInterimRef.current)
            : 5200;
          const remaining=Math.max(80,pauseMs-current.silenceMs);
          const tryFinalize=()=>{
            silenceTimerRef.current=null;
            if(isProcessingTurnRef.current||isAiSpeakingRef.current||
               statusRef.current!=='listening'||micMutedRef.current)return;
            const candidate=activeTranscriptRef.current.trim();
            const acousticSilence=vadRef.current.silenceDuration(Date.now());
            const wait=candidate
              ? forzaTurnRemainingWaitMs(
                  candidate,speechInterimRef.current,
                  Date.now()-lastTranscriptChangedAtRef.current,
                  vadRef.current.heardSpeech?acousticSilence:null)
              : Math.max(0,Math.max(5200,pauseMs)-acousticSilence);
            if(wait>0){
              silenceTimerRef.current=window.setTimeout(tryFinalize,Math.max(80,wait));
              return;
            }
            setIsUserSpeaking(false);
            detectedSpeechEndAtRef.current=performance.now()-acousticSilence;
            console.info('[FORZA_LATENCY] phase=vad_end_detected silenceMs='+
              Math.round(acousticSilence));
            if(candidate){
              sessionTranscriptRef.current=appendForzaSessionTurn(sessionTranscriptRef.current,candidate);
              pendingCommittedTranscriptRef.current=candidate;
              setUserText(sessionTranscriptRef.current);
              pendingTranscriptRef.current=candidate;
              activeTranscriptRef.current='';
              recognitionSessionBaseRef.current='';
              lastTranscriptChangedAtRef.current=0;
              vadRef.current.reset();
              const recorder=mediaRecorderRef.current;
              if(recorder?.state==='recording'){
                // Stop once at the acoustic boundary so the server receives
                // exactly this utterance, not a 45-second rolling recording.
                recorder.stop();
              }else{
                pendingTranscriptRef.current='';
                hasSpeechSoundRef.current=false;
                void handleUserFinishedSpeaking(candidate);
              }
            }else if(mediaRecorderRef.current?.state==='recording'){
              // Preserve the server STT fallback when browser STT is unavailable.
              mediaRecorderRef.current.stop();
              vadRef.current.reset();
            }else{
              hasSpeechSoundRef.current=false;
              vadRef.current.reset();
            }
          };
          silenceTimerRef.current=window.setTimeout(tryFinalize,remaining);
        }
      }catch(err){
        console.warn('[FORZA] Audio analyser failed',(err as any)?.name||'audio_error');
      }
    };
    const micPoll=window.setInterval(check,55);
    return()=>{
      active=false;
      window.clearInterval(micPoll);
      if(silenceTimerRef.current){clearTimeout(silenceTimerRef.current);silenceTimerRef.current=null;}
    };
  },[]);

  // Compute reactive mode for Three.js ParticleAvatar
  const avatarMode = status === 'speaking' ? 'speak' : status === 'listening' ? 'listen' : 'auto';
  const avatarIntensity = status === 'speaking' ? 1.45 : status === 'thinking' ? 0.6 : 1.0;

  // Reduced motion preference
  useEffect(() => {
    const motion = matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReducedMotion(motion.matches);
    update();
    motion.addEventListener('change', update);
    return () => motion.removeEventListener('change', update);
  }, []);

  // Keyboard shortcuts matching provided template
  useEffect(() => {
    function keyboard(e: KeyboardEvent) {
      if (/INPUT|SELECT|TEXTAREA|BUTTON/.test((e.target as HTMLElement).tagName)) return;
      if (e.code === 'Space') {
        e.preventDefault();
        setPaused(p => !p);
      }
      if (e.key.toLowerCase() === 'h') setClean(c => !c);
      if (e.key.toLowerCase() === 'r') {
        setRevision(r => r + 1);
        avatarRef.current?.reform();
        setPaused(false);
      }
      if (e.key.toLowerCase() === 'b') {
        avatarRef.current?.burst();
      }
      if (e.key.toLowerCase() === 'p') {
        avatarRef.current?.snap();
      }
      if (e.key.toLowerCase() === 's') {
        setSpeed(s => (s === 1 ? 2 : s === 2 ? 3.5 : 1));
      }
    }
    document.addEventListener('keydown', keyboard);
    return () => document.removeEventListener('keydown', keyboard);
  }, []);

  // Fullscreen toggle
  async function fullscreen() {
    try {
      setFullscreenError('');
      if (document.fullscreenElement) {
        await document.exitFullscreen();
      } else if (shell.current?.requestFullscreen) {
        await shell.current.requestFullscreen();
      } else {
        setFullscreenError('حالت تمام‌صفحه در این مرورگر پشتیبانی نمی‌شود.');
      }
    } catch {
      setFullscreenError('امکان ورود به حالت تمام‌صفحه وجود ندارد.');
    }
  }

  // Streamed answer text must be visible as soon as each server chunk arrives.
  // Re-running a typewriter animation on every chunk hides the live response.
  useEffect(() => {
    setDisplayedAi(aiText || '');
  }, [aiText]);

  // Keep the newest live words visible while retaining the complete scrollback.
  useEffect(()=>{
    const card=transcriptCardRef.current;
    if(card)card.scrollTop=card.scrollHeight;
  },[userText,displayedAi]);

  // Keep the first-audio wait observable instead of showing an indefinitely
  // frozen spinner while the CPU-based Pocket model is synthesizing speech.
  useEffect(() => {
    if (!voicePending) {
      setVoiceWaitSeconds(0);
      return;
    }
    const started = Date.now();
    setVoiceWaitSeconds(0);
    const timer = window.setInterval(() => {
      setVoiceWaitSeconds(Math.floor((Date.now() - started) / 1000));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [voicePending]);

  // Call duration timer
  useEffect(() => {
    if (!isCallActive) return;
    const id = window.setInterval(() => setSeconds(s => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [isCallActive]);

  const ensureCtx = useCallback(() => {
    if(callClosedRef.current)return null;
    if (!ctxRef.current) ctxRef.current=getForzaAudioContext();
    if (ctxRef.current && ctxRef.current.state === 'suspended') {
      void ctxRef.current.resume().catch(()=>{});
    }
    return ctxRef.current;
  }, []);

  const stopAudio = useCallback(() => {
    stopAcknowledgementRef.current?.cancel();
    manualReplayAbortRef.current?.abort(new Error('forza_manual_replay_stopped'));
    manualReplayAbortRef.current=null;
    isManualReplayPendingRef.current=false;
    continuousVoiceRef.current?.cancel();
    continuousVoiceRef.current=null;
    try { window.speechSynthesis?.cancel(); } catch {}
    const pending = pendingAudioResolveRef.current;
    pendingAudioResolveRef.current = null;
    pending?.();
    const source = currentBufferSourceRef.current;
    currentBufferSourceRef.current = null;
    try { source?.stop(); } catch {}
    isAiSpeakingRef.current = false;
    const a = audioElRef.current;
    if (a) {
      try {
        a.pause();
        a.currentTime = 0;
      } catch {}
    }
  }, []);

  const interruptCurrentTurn = useCallback(() => {
    const active=activeTurnRef.current;
    if(!active || active.abort.signal.aborted){
      // Manual replay has no LLM turn but must still be interruptible.
      if(continuousVoiceRef.current||isManualReplayPendingRef.current){
        stopAudio();
        setVoicePending(false);
        setVoiceStage('idle');
        setStatus('listening');
        setTurn('user');
      }
      return;
    }
    // Invalidate callbacks before aborting. The old finally must not cancel
    // the new user's microphone, player or response.
    activeTurnRef.current=null;
    active.abort.abort(new Error('forza_customer_interrupted'));
    stopAudio();
    // Preserve only the last 500ms of in-RAM mic pre-roll for the customer's
    // first syllables; older chunks may contain FORZA's own speaker output.
    // Playback cancellation has now measured a partially played WAV.
    active.markInterrupted?.();
    isProcessingTurnRef.current=false;
    isAiSpeakingRef.current=false;
    setVoicePending(false);
    setVoiceStage('idle');
    setStatus('listening');
    setTurn('user');
    setIsUserSpeaking(true);
    console.info('[FORZA_TURN] phase=customer-interrupt turn='+active.generation);
  },[stopAudio,setStatus]);
  interruptRequestRef.current=interruptCurrentTurn;

  useEffect(()=>{
    speakerMutedRef.current=isSpeakerMuted;
    continuousVoiceRef.current?.setMuted(isSpeakerMuted);
  },[isSpeakerMuted]);

  // Preserve the pre-recorded greeting and manual playback fallback.
  // Some browsers reject a valid Piper WAV in HTMLAudioElement but can decode it.
  const playDataUrl = useCallback((url: string): Promise<void> => new Promise((resolve,reject) => {
    if(callClosedRef.current)return reject(new Error('forza_call_closed'));
    if (!url) return reject(new Error('audio_missing'));
    stopAudio();
    let audio = audioElRef.current;
    if (!audio) {
      audio = new Audio();
      audioElRef.current = audio;
    }
    audio.pause();
    // Preserve the buffered, same-origin Pocket greeting; rewriting src forces
    // an unnecessary fetch exactly when the particles finish.
    const targetUrl = new URL(url, window.location.href).href;
    // A preload can fail while the private voice worker is still warming.
    // Re-load the same URL rather than reusing a poisoned HTMLMediaElement.
    if (audio.src !== targetUrl || audio.error) {
      audio.src = url;
      audio.load();
    }
    audio.muted = isSpeakerMuted;
    audio.volume = 1;
    let settled = false;
    let fallbackStarted = false;
    let startWatchdog: number | undefined;
    let endWatchdog: number | undefined;
    let cancelPending: () => void = () => {};
    const cleanup = () => {
      audio.removeEventListener('ended', ended);
      audio.removeEventListener('error', failed);
      audio.removeEventListener('playing', playing);
    };
    const finish = (err?: Error) => {
      if (settled) return;
      settled = true;
      if(startWatchdog !== undefined) window.clearTimeout(startWatchdog);
      if(endWatchdog !== undefined) window.clearTimeout(endWatchdog);
      cleanup();
      if (pendingAudioResolveRef.current === cancelPending) pendingAudioResolveRef.current = null;
      isAiSpeakingRef.current = false;
      if (err) reject(err);
      else resolve();
    };
    cancelPending = () => finish();
    pendingAudioResolveRef.current = cancelPending;
    const playing = () => {
      if(settled)return;
      if(startWatchdog !== undefined) window.clearTimeout(startWatchdog);
      if(endWatchdog === undefined) {
        const duration = Number.isFinite(audio.duration) && audio.duration > 0
          ? audio.duration * 1000 + 6000 : 45000;
        endWatchdog = window.setTimeout(
          () => finish(new Error('amir_audio_end_timeout')),
          Math.min(90000, Math.max(10000, duration)),
        );
      }
      isAiSpeakingRef.current = true;
      setVoicePending(false);
      setStatus('speaking');
      setTurn('ai');
      setAutoplayBlocked(false);
      setPendingAudioUrl(null);
    };
    const ended = () => finish();
    const playViaWebAudio = async () => {
      const ctx = ensureCtx();
      if (!ctx) throw new Error('audio_context_unavailable');
      if (ctx.state === 'suspended') await ctx.resume();
      if (settled) return;
      const response = await fetch(url);
      if (!response.ok) throw new Error('audio_blob_unreadable');
      const decoded = await ctx.decodeAudioData(await response.arrayBuffer());
      if (settled) return;
      const source = ctx.createBufferSource();
      source.buffer = decoded;
      source.connect(ctx.destination);
      currentBufferSourceRef.current = source;
      source.onended = () => {
        if (currentBufferSourceRef.current === source) currentBufferSourceRef.current = null;
        finish();
      };
      playing();
      source.start(0);
    };
    const failed = () => {
      if (settled || fallbackStarted) return;
      // A network/HTTP error must not trigger a second request while the
      // private TTS worker is still generating the same greeting. WebAudio
      // recovery is reserved for a genuine media decode failure.
      if(audio.error?.code!==3){
        finish(new Error('audio-playback-failed'));
        return;
      }
      audio.pause();
      fallbackStarted = true;
      cleanup();
      void playViaWebAudio().catch((error: any) => {
        console.warn('[FORZA audio] HTMLAudio and WebAudio playback failed', error?.name || error?.message || 'audio_error');
        finish(new Error('audio-playback-failed'));
      });
    };
    audio.addEventListener('ended', ended);
    audio.addEventListener('error', failed);
    audio.addEventListener('playing', playing);
    startWatchdog = window.setTimeout(() => {
      if(!settled && !isAiSpeakingRef.current) {
        // The greeting is synthesized once by the private voice worker. Do
        // not issue a second WebAudio fetch while that first WAV is still
        // being generated; it can occupy the worker queue and break welcome.
        console.warn('[FORZA Audio] playback start timeout');
        finish(new Error('forza_audio_start_timeout'));
      }
    }, 18000);
    void audio.play().then(playing).catch((error: any) => {
      if (settled) return;
      if (error?.name === 'NotAllowedError') {
        // The navigation click may already have unlocked our shared AudioContext
        // even though HTMLAudioElement playback is still blocked. Use that
        // gesture-authorized context before asking the customer to click again.
        const unlockedContext = ensureCtx();
        if (unlockedContext?.state === 'running' && !fallbackStarted) {
          audio.pause();
          fallbackStarted = true;
          cleanup();
          console.info('[FORZA greeting] autoplay_fallback=shared_webaudio');
          void playViaWebAudio().catch((fallbackError: any) => {
            console.warn('[FORZA audio] unlocked WebAudio greeting failed',
              fallbackError?.name || fallbackError?.message || 'audio_error');
            setAutoplayBlocked(true);
            setPendingAudioUrl(url);
            finish(new Error('autoplay_permission_required'));
          });
          return;
        }
        setAutoplayBlocked(true);
        setPendingAudioUrl(url);
        finish(new Error('autoplay_permission_required'));
      } else {
        failed();
      }
    });
  }), [ensureCtx, isSpeakerMuted, setStatus, stopAudio]);


  // Exactly one full answer per turn. Do not split at punctuation, SSE tokens,
  // words or phoneme phrases in the browser. This is the SAME original Pocket
  // Farsi voice /speak service, not browser SpeechSynthesis or a new model.
  // WAV stays in RAM: no browser audio cache or blob URL files.
  const requestPocketAudio=useCallback(async(
    answer:string,
    signal?:AbortSignal,
    turnId?:string,
  ):Promise<Uint8Array>=>{
    const text=answer.trim();
    if(!text)throw new Error('forza_empty_answer');
    const started=performance.now();
    // Bound live Nima phrases without changing the legacy full-answer Pocket
    // contract, whose CPU synthesis can legitimately exceed a minute.
    const timeoutSignal=voiceModeRef.current==='piper-nima-gyro-medium'
      ? AbortSignal.timeout(65000) : AbortSignal.timeout(420000);
    const requestTurnId=turnId||('call-'+callIdRef.current+'-tts-'+Math.round(performance.now()));
    const response=await fetch('/api/ai/forza-speech',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({text,turnId:requestTurnId}),
      signal:signal
        ? AbortSignal.any([signal,timeoutSignal])
        : timeoutSignal,
    });
    if(!response.ok){
      const failure:any=await response.clone().json().catch(()=>null);
      const code=String(failure?.errorCode||failure?.error||'unknown')
        .replace(/[^a-zA-Z0-9_-]/g,'').slice(0,64);
      console.warn('[FORZA_TTS_STAGE] phase=http_error status='+response.status+' code='+code);
      if(response.status===429){
        if(code==='forza_network_limit')throw new Error('pocket_rate_limited_network');
        if(code==='forza_turn_limit')throw new Error('pocket_rate_limited_turn');
        throw new Error('pocket_http_429');
      }
      throw new Error('pocket_http_'+response.status+'_'+code);
    }
    // The private voice health check is authoritative. Recover gracefully if
    // the first request races voice-info instead of discarding a valid WAV.
    const returnedVoice=response.headers.get('X-Forza-Voice');
    if(returnedVoice==='piper-nima-gyro-medium'){
      voiceModeRef.current='piper-nima-gyro-medium';
      setActiveVoiceLabel('نیما (Piper فارسی)');
    }else if(returnedVoice==='piper-amir-medium'){
      voiceModeRef.current='piper-amir-medium';
      setActiveVoiceLabel('امیر (Piper فارسی)');
    }else if(returnedVoice==='pocket-farsi-v2'){
      voiceModeRef.current='pocket-farsi-v2';
      setActiveVoiceLabel('Pocket TTS فارسی v2');
    }else throw new Error('forza_unknown_voice_identity');
    if(!(response.headers.get('Content-Type')||'').includes('audio/wav'))
      throw new Error('forza_pocket_full_answer_not_wav');
    const wavHeadersAt=performance.now();
    const audio=new Uint8Array(await response.arrayBuffer());
    console.info('[FORZA_TTS_STAGE] turn='+String(turnId||'unknown')+
      ' phase=wave_received clientMs='+Math.round(performance.now()-started)+
      ' headerWaitMs='+Math.round(wavHeadersAt-started)+
      ' transferMs='+Math.round(performance.now()-wavHeadersAt)+
      ' workerQueueMs='+String(response.headers.get('X-Forza-Queue-Ms')||'unknown')+
      ' workerInferenceMs='+String(response.headers.get('X-Forza-Inference-Ms')||'unknown')+
      ' bytes='+audio.byteLength);
    if(audio.byteLength<44||audio.byteLength>8_000_000 ||
       String.fromCharCode(...audio.subarray(0,4))!=='RIFF' ||
       String.fromCharCode(...audio.subarray(8,12))!=='WAVE')
      throw new Error('forza_invalid_full_answer_wav');
    if(signal?.aborted || callClosedRef.current)throw new Error('forza_tts_aborted');
    if(voiceModeRef.current==='piper-nima-gyro-medium'){
      console.info('[FORZA_LATENCY] phase=nima-phrase-wav-ready ms='+
        Math.round(performance.now()-started)+' chars='+text.length+
        ' bytes='+audio.byteLength);
    }else{
      console.info('[FORZA_LATENCY] phase=whole-pocket-wav-ready ms='+
        Math.round(performance.now()-started)+' chars='+text.length+
        ' bytes='+audio.byteLength);
    }
    return audio;
  },[setActiveVoiceLabel]);

  useEffect(()=>{
    if(greetingPhase!=='complete'||voiceModeRef.current!=='piper-nima-gyro-medium')return;
    const acknowledgement=new ForzaStopAcknowledgement(signal=>
      requestPocketAudio('بله، بفرما.',signal,'call-'+callIdRef.current+'-stop-ack'));
    stopAcknowledgementRef.current=acknowledgement;
    void acknowledgement.warm();
    return ()=>{
      acknowledgement.dispose();
      if(stopAcknowledgementRef.current===acknowledgement)stopAcknowledgementRef.current=null;
    };
  },[greetingPhase,activeVoiceLabel,requestPocketAudio]);

  const playPocketFullAnswer=useCallback(async(
    answer:string,
    player:ForzaContinuousWav,
    signal?:AbortSignal,
    turnId?:string,
  ):Promise<void>=>{
    // One HTTP POST, one RIFF/WAVE, one AudioBufferSource: no waiting
    // for a second generated packet mid-sentence, including punctuation.
    const audio=await requestPocketAudio(answer,signal,turnId);
    if(signal?.aborted || callClosedRef.current)return;
    await player.enqueueWav(audio);
    console.info('[FORZA_LATENCY] phase=whole-pocket-playback-finished '+
      'audio_buffers=1 underruns='+player.underrunCount);
  },[requestPocketAudio]);

  const playSpeechPhrase=useCallback(async(phrase:string):Promise<void>=>{
    continuousVoiceRef.current?.cancel();
    const controller=new AbortController();
    manualReplayAbortRef.current=controller;
    isManualReplayPendingRef.current=true;
    const player=new ForzaContinuousWav(ensureCtx,()=>{
      isAiSpeakingRef.current=true;
      setVoicePending(false);
      setStatus('speaking');
      setTurn('ai');
    },ms=>console.warn('[FORZA_AUDIO_UNDERRUN] wait_ms='+ms));
    player.setMuted(isSpeakerMuted);
    continuousVoiceRef.current=player;
    try{
      await playPocketFullAnswer(phrase,player,controller.signal,
        'call-'+callIdRef.current+'-replay-'+Math.round(performance.now()));
      if(!callClosedRef.current&&!controller.signal.aborted)setVoiceOutputError(null);
    }catch(error:any){
      if(!callClosedRef.current&&!controller.signal.aborted)setVoiceOutputError(
        error?.message==='autoplay_permission_required'
          ?'برای پخش صوت یک‌بار صفحه را لمس کنید.'
          :'صدای FORZA از سرور Ubuntu دریافت نشد؛ متن پاسخ نمایش داده شده است.');
      if(!controller.signal.aborted)
        console.warn('[FORZA Pocket Ubuntu] phrase failed',String(error?.message||'error').slice(0,90));
      throw error;
    }finally{
      player.cancel();
      if(continuousVoiceRef.current===player)continuousVoiceRef.current=null;
      if(manualReplayAbortRef.current===controller){
        manualReplayAbortRef.current=null;
        isManualReplayPendingRef.current=false;
        isAiSpeakingRef.current=false;
      }
    }
  },[ensureCtx,isSpeakerMuted,playPocketFullAnswer,setStatus]);

  const speakText = useCallback(async (text: string) => {
    if(text===GREETING_TEXT){
      stopListening();
    }else{
      // Manual replay must remain interruptible, including while generating.
      heardSpeechEchoRef.current=text;
      isManualReplayPendingRef.current=true;
      startListening(true);
    }
    setVoiceOutputError(null);
    setStatus(text === GREETING_TEXT ? 'idle' : 'thinking');
    setTurn('ai');

    if (text === GREETING_TEXT) {
      // The exact greeting was synthesized by Pocket Farsi v2 at image build time.
      // No model download or inference is needed at the 100% particle event.
      const url = '/forza-greeting-bootstrap.wav';
      await playDataUrl(url);
      console.info('[FORZA greeting] selected server voice welcome finished');
      return;
    }

    // Request and play one complete WAV. No network/player chunk boundaries.
    if(text.trim())await playSpeechPhrase(text.trim());
  }, [playSpeechPhrase,setStatus,stopListening,startListening]);

  const replayAiVoice = useCallback(async () => {
    const text = aiText.trim();
    if (!text) return;
    setVoiceOutputError(null);
    // Replay triggers fresh synthesis. Customer audio never remains cached.
    try {
      await speakText(text);
    } catch (error:any) {
      // An intentional customer interruption is not a TTS outage.
      const code=String(error?.message||error?.name||'');
      if(!/aborted|stopped|interrupted|cancelled/i.test(code))
        setVoiceOutputError(code === 'autoplay_permission_required'
          ? 'برای پخش صدا، یک بار صفحه را لمس یا کلیک کنید.'
          : 'صدای فورزا از سرویس صوتی در دسترس نیست؛ اتصال Ubuntu را بررسی کنید.');
    } finally {
      if(greetingFinishedRef.current && !isProcessingTurnRef.current &&
         !activeTranscriptRef.current.trim())startListening();
    }
  },[aiText,playDataUrl,speakText,startListening,stopListening]);

  // A user gesture permits browser audio, but it never skips the greeting.
  const unlockAudio = useCallback(() => {
    ensureCtx();
    setVoiceOutputError(null);
    setGreetingPhase('preparing');
    const url=pendingAudioUrl;
    if(url) {
      setPendingAudioUrl(null);
      void playDataUrl(url)
        .then(()=>{
          if(!greetingFinishedRef.current) {
            greetingFinishedRef.current=true;
            setGreetingPhase('complete');
          }
          setStatus('listening');
          setTurn('user');
          startListening();
        })
        .catch((error:any)=>{
          console.warn('[FORZA] User-initiated greeting failed',error?.message||'audio_error');
          setGreetingPhase('needs-permission');setAutoplayBlocked(true);setStatus('idle');
          setVoiceOutputError('پخش صدای خوشامدگویی انجام نشد؛ لطفاً مجدداً تلاش کنید.');
        });
    } else {
      setAutoplayBlocked(false);
      if(!greetingFinishedRef.current) {
        void speakText(GREETING_TEXT).then(()=>{
          greetingFinishedRef.current=true;
          setGreetingPhase('complete');
          setStatus('listening');
          setTurn('user');
          startListening();
        }).catch((error:any)=>{
          console.warn('[FORZA] User-initiated greeting failed',error?.message||'audio_error');
          setGreetingPhase('needs-permission');setAutoplayBlocked(true);setStatus('idle');
          setVoiceOutputError('پخش صدای خوشامدگویی انجام نشد؛ لطفاً مجدداً تلاش کنید.');
        });
      }
    }
  },[ensureCtx,pendingAudioUrl,playDataUrl,setStatus,startListening,speakText]);

  // Turn management: send speech/query to AI & worker
  const handleUserFinishedSpeaking = useCallback(
    async (textToSend?: string, audioBlob?: Blob | Blob[], audioMime?: string) => {
      const q = (textToSend || '').trim();
      if(callClosedRef.current)return;
      if(turnDispatchPendingRef.current && !(q && forzaTurnIntent(q)==='stop'))return;
      if (!q && !audioBlob) return;
      // No recognized words does not establish a failed user turn. VAD can
      // detect noise or residual speaker audio while WebSpeech is reconnecting.
      // Never start an unavailable server fallback or clear the last valid text.
      if(!q&&audioBlob&&serverSttConfiguredRef.current===false){
        if(recognitionFailedRef.current||webSpeechFailedRef.current)
          setMicrophoneError('ارتباط تشخیص گفتار مرورگر قطع است؛ روی «اتصال دوباره میکروفون» بزنید.');
        startListening(true);
        return;
      }
      if (!greetingFinishedRef.current) return;
      if (isAiSpeakingRef.current || statusRef.current === 'thinking' || isProcessingTurnRef.current) {
        // A typed correction or stop command must not be locked out while
        // FORZA is generating or playing the previous answer.
        if(!q)return;
        interruptCurrentTurn();
      }
      if(q && forzaTurnIntent(q)==='stop'){
        // A pure stop command should not trigger an extra AI response.
        sessionTranscriptRef.current=appendForzaSessionTurn(sessionTranscriptRef.current,q);
        setUserText(sessionTranscriptRef.current);
        setIsUserSpeaking(false);
        setStatus('listening');
        setTurn('user');
        activeTranscriptRef.current='';
        recognitionSessionBaseRef.current='';
        // Keep Chrome's cumulative recognition from replaying the stop words
        // as the next customer turn when the recognizer remains active.
        recognitionConsumedCountRef.current=recognitionCheckpointRef.current.count;
        recognitionConsumedInterimRef.current={...recognitionCheckpointRef.current.interim};
        localSttFinalRef.current='';
        localSttAdmissionRef.current?.reset();
        lastTranscriptChangedAtRef.current=0;
        turnDispatchPendingRef.current=false;
        vadRef.current.reset();
        setAiText('بله، بفرما.');setDisplayedAi('بله، بفرما.');
        stopAcknowledgementRef.current?.request(async(bytes,controller)=>{
          if(callClosedRef.current||activeTranscriptRef.current.trim()||isProcessingTurnRef.current||speakerMutedRef.current)return;
          manualReplayAbortRef.current=controller;
          isManualReplayPendingRef.current=true;
          const player=new ForzaContinuousWav(ensureCtx,()=>{
            if(controller.signal.aborted||callClosedRef.current)return;
            heardSpeechEchoRef.current='بله، بفرما.';
            playbackEchoHistoryRef.current.record('بله، بفرما.');
            lastForzaPlaybackAtRef.current=Date.now();
            isAiSpeakingRef.current=true;setStatus('speaking');setTurn('ai');
          });
          continuousVoiceRef.current=player;
          const cancel=()=>player.cancel();
          controller.signal.addEventListener('abort',cancel,{once:true});
          try{await player.enqueueWav(bytes);}finally{
            controller.signal.removeEventListener('abort',cancel);
            player.cancel();
            if(continuousVoiceRef.current===player)continuousVoiceRef.current=null;
            if(manualReplayAbortRef.current===controller){
              manualReplayAbortRef.current=null;isManualReplayPendingRef.current=false;
              isAiSpeakingRef.current=false;lastForzaPlaybackAtRef.current=Date.now();
              if(!callClosedRef.current&&!isProcessingTurnRef.current){setStatus('listening');setTurn('user');}
            }
          }
        });
        return;
      }

      // Claim the turn synchronously. The voice identity lookup now runs
      // inside the owned/abortable turn below, so speech arriving during that
      // lookup can still barge in instead of being erased by a later reset.
      // Commit the recognized words before any asynchronous STT verifier or
      // model request can be interrupted. A resumed customer phrase must never
      // make this already-heard transcript disappear.
      const transcriptAlreadyCommitted=Boolean(q&&pendingCommittedTranscriptRef.current===q);
      pendingCommittedTranscriptRef.current='';
      if(q){
        if(!transcriptAlreadyCommitted){
          sessionTranscriptRef.current=appendForzaSessionTurn(sessionTranscriptRef.current,q);
          setUserText(sessionTranscriptRef.current);
        }
        // Put the user words into conversation history before any asynchronous
        // server verifier. If the customer interrupts during STT, the next LLM
        // request still receives this context instead of losing the last turn.
        const prior=historyRef.current.slice(-FORZA_CONVERSATION_HISTORY_LIMIT);
        historyRef.current=[...prior,{role:'user',text:q}];
        pendingHistoryTurnRef.current=q;
      }
      turnDispatchPendingRef.current=true;
      stopAcknowledgementRef.current?.cancel();
      // Chrome keeps final results from older turns while recognition stays
      // open to hear interruptions. Mark them consumed instead of stopping
      // and restarting the mic (which drops first syllables).
      recognitionConsumedCountRef.current=recognitionCheckpointRef.current.count;
        recognitionConsumedInterimRef.current={...recognitionCheckpointRef.current.interim};
      recognitionSessionBaseRef.current='';
      localSttFinalRef.current='';
      localSttAdmissionRef.current?.reset();
      turnDispatchPendingRef.current=false;
      heardSpeechEchoRef.current='';
      lastForzaPlaybackAtRef.current=0;
      isProcessingTurnRef.current = true;
      setVoicePending(false);
      setVoiceStage('text');
      setErrorNotice(null);
      // Keep browser/local recognition and mic recording alive during the
      // model request. Stopping then immediately restarting WebSpeech loses
      // the first syllable of a customer interruption on some browsers.
      // Only the previous transcript is cleared; VAD resets below.
      // No audio-unlock call here: it can accidentally replay the introduction
      // while the customer's recording is being submitted.
      setStatus('thinking');
      setTurn('ai');
      // Never display the previous answer as if it belonged to this turn.
      // As soon as the first SSE token arrives, it replaces this empty area.
      setAiText('');
      setDisplayedAi('');
      activeTranscriptRef.current = '';
      recognitionSessionBaseRef.current='';

      if (q) {
        setUserText(sessionTranscriptRef.current);
      } else {
        // The raw-audio fallback cannot invent a transcript before recognition;
        // keep previously displayed live words instead of replacing them with
        // a misleading "receiving/sending audio" spinner.
        setUserText(previous=>previous.trim());
      }

      const pocketAbort=new AbortController();
      const generation=++generationRef.current;
      activeTurnRef.current={generation,abort:pocketAbort};
      console.info('[FORZA_TURN] turn='+generation+
        ' phase=request_preparation_end_to_turn_ms='+
        (detectedSpeechEndAtRef.current?Math.round(performance.now()-detectedSpeechEndAtRef.current):-1));
      vadRef.current.reset();
      startListening(true); // monitor barge-in, without changing the AI status
      let playerForTurn:ForzaContinuousWav|null=null;
      let bufferedNima:ForzaNimaBufferedSpeech|null=null;
      let terminalIdleTimer:number|null=null;
      try {
        // A slow voice-health probe must not create an unowned gap before the
        // turn controller exists. This turn is already abortable and the mic
        // remains live, so the customer can interrupt even during warmup.
        await ensureVoiceMode();
        if(pocketAbort.signal.aborted || activeTurnRef.current?.generation!==generation)return;
        const payload: any = {
          history: historyRef.current.slice(-FORZA_CONVERSATION_HISTORY_LIMIT),
          // First deliver the exact AI words; synthesize audio as a second step.
          deferAudio: true,
        };

        if (q) {
          payload.query = q;
        }

        // Browser/local interim text stays visible immediately. On devices
        // using Chrome as the live recognizer, run the local server Diba model
        // as a bounded final verifier too; on devices already using local Diba,
        // avoid wasting a second inference on the same model.
        const needsServerFinal = Boolean(audioBlob) &&
          serverSttConfiguredRef.current === true && (!q || !localSttActiveRef.current);
        if(audioBlob && needsServerFinal){
          const audioBlobs=Array.isArray(audioBlob)?audioBlob:[audioBlob];
          const sttStartedAt=performance.now();
          const sttAbort=new AbortController();
          // Every rotated WebM segment is transcribed with at most two requests
          // in flight. Scale the deadline with segment count instead of imposing
          // a fixed total recording-duration ceiling.
          const sttBudgetMs=Math.max(25_000,Math.ceil(audioBlobs.length/2)*22_000+5_000);
          const sttTimer=window.setTimeout(
            ()=>sttAbort.abort(new Error('تبدیل گفتار به متن بیش از حد طول کشید.')),
            sttBudgetMs,
          );
          let serverTranscript='';
          let failedSegments=0;
          try{
            // Each MediaRecorder rotation is a complete WebM container. Decode
            // segments in parallel (the server has two bounded Diba workers),
            // then merge in original recording order to avoid dropping the
            // beginning of a long utterance behind a serial 10s timeout.
            const results=await mapForzaSegmentsInOrder(audioBlobs,2,async segment=>{
              const reader=new FileReader();
              const base64Promise=new Promise<string>((resolve,reject)=>{
                reader.onloadend=()=>resolve(reader.result as string);
                reader.onerror=reject;
              });
              reader.readAsDataURL(segment);
              const audioBase64=extractForzaAudioBase64(await base64Promise);
              const sttResponse=await fetch('/api/ai/forza-live',{
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body:JSON.stringify({
                  audioBase64,
                  audioMimeType:audioMime||segment.type||'audio/webm',
                  transcribeOnly:true,
                }),
                signal:AbortSignal.any([sttAbort.signal,pocketAbort.signal]),
              });
              const sttData:any=await sttResponse.json().catch(()=>null);
              const transcript=String(sttData?.userTranscript||sttData?.text||'').trim();
              if(!sttResponse.ok||!sttData?.success||!transcript){
                throw new Error('diba_segment_http_'+sttResponse.status+'_'+
                  String(sttData?.errorCode||'empty').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,32));
              }
              return transcript;
            });
            for(const result of results){
              if(result.status==='fulfilled'){
                serverTranscript=appendForzaSpeechSegment(serverTranscript,result.value);
              }else{
                failedSegments++;
                const reason=result.reason instanceof Error?result.reason.message:'unknown';
                console.warn('[FORZA_STT] segment_final_unavailable code='+
                  String(reason).replace(/[^a-zA-Z0-9_-]/g,'').slice(0,48));
              }
            }
            serverTranscript=serverTranscript.trim();
            if(serverTranscript && (q || failedSegments===0)){
              payload.query=chooseForzaFinalTranscript(q,serverTranscript);
              console.info('[FORZA_STT] turn='+generation+' provider=diba-vosk duration_ms='+
                Math.round(performance.now()-sttStartedAt)+' segments='+audioBlobs.length+
                ' failed='+failedSegments+' source='+(payload.query===q?'browser_guarded':'server_final')+
                ' transcript_chars='+serverTranscript.length);
              setUserText(q
                ?replaceForzaLastSessionTurn(sessionTranscriptRef.current,q,payload.query)
                :composeForzaSessionTranscript(sessionTranscriptRef.current,payload.query));
              setMicrophoneError(null);
            }else if(!q){
              throw new Error('diba_no_complete_transcript');
            }else{
              console.info('[FORZA_STT] browser_fallback=1 server_segments_failed='+failedSegments);
            }
          }catch(sttError:any){
            if(pocketAbort.signal.aborted)throw sttError;
            console.warn('[FORZA_STT] server_final_error code='+
              String(sttError?.message||'unknown').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,64)+
              ' browser_fallback='+(q?'1':'0'));
            // A failed final verifier must never erase a usable live transcript.
            if(!q)throw new Error('متن گفتار کامل دریافت نشد؛ لطفاً یک‌بار دیگر صحبت کنید. اگر مشکل ادامه داشت، اتصال میکروفون را دوباره برقرار کنید.');
          }finally{
            window.clearTimeout(sttTimer);
          }
        }else if(audioBlob&&!q){
          throw new Error('متن گفتار دریافت نشد و موتور دایبا هم آماده نیست. لطفاً دوباره نزدیک میکروفون صحبت کنید یا پیام را تایپ کنید.');
        }

        if(pocketAbort.signal.aborted||activeTurnRef.current?.generation!==generation)return;

        // Render every incoming SSE delta immediately; the selected Nima
        // engine voices complete word groups before the LLM reply finishes.
        // Pocket fallback retains its one-request full-answer path.
        const turnStartedAt=performance.now();
        const resolvedUserQuery=String(payload.query||q).trim();
        // The live hypothesis was already committed before asynchronous STT.
        // Replace only this last turn if Diba supplies a better final transcript;
        // earlier turns remain untouched across pauses and assistant replies.
        if(resolvedUserQuery){
          sessionTranscriptRef.current=q
            ?replaceForzaLastSessionTurn(sessionTranscriptRef.current,q,resolvedUserQuery)
            :appendForzaSessionTurn(sessionTranscriptRef.current,resolvedUserQuery);
          setUserText(sessionTranscriptRef.current);
        }
        // Keep the prior conversation snapshot separate from this new user
        // turn. The API appends query as its final user message; including it
        // in history too would make every customer utterance appear twice.
        let previousHistory:Turn[];
        const lastHistoryEntry=historyRef.current[historyRef.current.length-1];
        const canReplacePendingHistory=Boolean(q&&pendingHistoryTurnRef.current===q&&
          lastHistoryEntry?.role==='user'&&lastHistoryEntry.text===q);
        if(canReplacePendingHistory){
          previousHistory=historyRef.current.slice(0,-1).slice(-FORZA_CONVERSATION_HISTORY_LIMIT);
          historyRef.current=[...previousHistory,{role:'user',text:resolvedUserQuery}];
        }else{
          const prepared=prepareForzaConversationTurn(
            historyRef.current,resolvedUserQuery,FORZA_CONVERSATION_HISTORY_LIMIT,
          );
          previousHistory=prepared.previousHistory;
          historyRef.current=prepared.nextHistory;
        }
        pendingHistoryTurnRef.current='';
        // Send only the sanitized prior turns; the current query remains the
        // separate final user message in the streaming request body.
        payload.history=previousHistory;
        if(resolvedUserQuery)setUserText(sessionTranscriptRef.current);
        let reply='';
        let firstTextDelivered=false;
        let firstPlaybackLogged=false;
        let heardEntry:Turn|null=null;
        let interruptedPhrase:{text:string;playedMs:number;durationMs:number}|null=null;
        const recordHeard=(phrase:string)=>{
          if(speakerMutedRef.current)return;
          if(activeTurnRef.current?.generation!==generation || pocketAbort.signal.aborted)return;
          if(!phrase.trim())return;
          if(!heardEntry){
            heardEntry={role:'model',text:''};
            historyRef.current.push(heardEntry);
          }
          heardEntry.text=[heardEntry.text,phrase.trim()].filter(Boolean).join(' ').trim();
        };
        if(activeTurnRef.current?.generation===generation){
          activeTurnRef.current.markInterrupted=()=>{
            if(!reply)return;
            const partial=interruptedPhrase;
            const note=partial
              ? 'عبارت «'+partial.text+'» فقط '+Math.round(partial.playedMs)+
                ' از '+Math.round(partial.durationMs)+' میلی‌ثانیه پخش شد و کامل شنیده‌شده نیست.'
              : 'عبارت جدیدِ در حال ساخت یا صف، پخش کامل نداشته است.';
            historyRef.current.push({role:'model',
              text:'[پاسخ قطع شد. فقط عبارت‌های کاملِ قبلی شنیده‌شده محسوب شوند. '+
                note+' اگر کاربر گفت ادامه بده از آخرین عبارت کامل شروع کن؛ متن ساخته‌شده بعدی را شنیده‌شده فرض نکن.]'});
          };
        }
        continuousVoiceRef.current?.cancel();
        const continuousPlayer=new ForzaContinuousWav(
          ensureCtx,
          ()=>{
            if(activeTurnRef.current?.generation!==generation)return;
            isAiSpeakingRef.current=true;
            lastForzaPlaybackAtRef.current=Date.now();
            setVoicePending(false);
            setVoiceStage('playing');
            setStatus('speaking');
            setTurn('ai');
          },
          ms=>console.warn('[FORZA_AUDIO_UNDERRUN] turn='+generation+' wait_ms='+ms+
            ' cause=next_wav_arrived_after_previous_playback'),
          ()=>{
            if(activeTurnRef.current?.generation!==generation)return;
            isAiSpeakingRef.current=false;
            setVoicePending(true);
            setVoiceStage('buffering');
            setStatus('thinking');
          },
          (stage,ms)=>{
            if(stage==='playback_started'&&!firstPlaybackLogged){
              firstPlaybackLogged=true;
              if(detectedSpeechEndAtRef.current>0){
                const latency=Math.round(performance.now()-detectedSpeechEndAtRef.current);
                const samples=endToPlaybackSamplesRef.current;
                samples.push(latency);
                if(samples.length>200)samples.shift();
                const ordered=[...samples].sort((a,b)=>a-b);
                const median=ordered[Math.floor((ordered.length-1)*0.5)];
                const p95=ordered[Math.ceil(ordered.length*0.95)-1];
                const mean=Math.round(ordered.reduce((sum,ms)=>sum+ms,0)/ordered.length);
                console.info('[FORZA_END_TO_AUDIO] turn='+generation+' ms='+latency+
                  ' n='+ordered.length+' meanMs='+mean+' medianMs='+median+' p95Ms='+p95+
                  ' estimatedAudioEnd=1 noPrivateContent=1');
              }
            }
            console.info('[FORZA_AUDIO_STAGE] turn='+generation+
              ' phase='+stage+' ms='+ms+' clientMs='+Math.round(performance.now()-turnStartedAt)+
              ' endToPlaybackMs='+(stage==='playback_started'&&detectedSpeechEndAtRef.current
                ? Math.round(performance.now()-detectedSpeechEndAtRef.current):-1));
          },
        );
        playerForTurn=continuousPlayer;
        continuousPlayer.setMuted(isSpeakerMuted);
        continuousVoiceRef.current=continuousPlayer;
        // Nima: group *complete words* across punctuation, so a full stop
        // never forces its own neural WAV or an avoidable gap. Stream tokens
        // to subtitles immediately and keep the Pocket fallback unchanged.
        const useNima=voiceModeRef.current==='piper-nima-gyro-medium';
        const phrasePlanner=new ForzaIncrementalSpeechText();
        const callPlainText=new ForzaCallPlainText();
        // Text updates are displayed immediately. Piper gets its first small,
        // completed word group while SSE continues, then synthesizes further
        // phrases in bounded lookahead on the same AudioContext clock.
        // Begin the first ready WAV with only a tiny optional buffer hold.
        bufferedNima=new ForzaNimaBufferedSpeech({
          synthesize:(phrase,signal)=>requestPocketAudio(forzaSpokenPlainText(phrase),signal,
            'call-'+callIdRef.current+'-turn-'+generation),
          player:continuousPlayer,
          signal:pocketAbort.signal,
          onPhrasePlayed:recordHeard,
          onPhraseReady:info=>{
            if(activeTurnRef.current?.generation!==generation)return;
            console.info('[FORZA_TTS_STAGE] turn='+generation+
              ' phase=phrase_wav_ready index='+info.index+
              ' queueClientMs='+info.waitMs+' requestClientMs='+info.fetchMs+
              ' wavBytes='+info.wavBytes+' wavDurationMs='+info.durationMs);
          },
          onPhraseProgress:(phrase,progress)=>{
            if(progress.phase==='started'){
              playbackEchoHistoryRef.current.record(phrase);
              heardSpeechEchoRef.current=phrase;
              lastForzaPlaybackAtRef.current=Date.now();
            }else if(progress.phase==='finished'){
              playbackEchoHistoryRef.current.record(phrase);
              lastForzaPlaybackAtRef.current=Date.now();
            }
            if(progress.phase==='interrupted' && progress.playedMs>0 &&
               progress.playedMs<progress.durationMs && !speakerMutedRef.current){
              interruptedPhrase={text:phrase,playedMs:progress.playedMs,
                durationMs:progress.durationMs};
            }
          },
          // The private Nima service defaults to one CPU inference worker.
          // Two parallel phrase requests can fill its 2.5s FIFO waiter and
          // make the second phrase fail, cancelling the rest of the answer.
          maxConcurrent:1,
          maxAheadPhrases:2,
          initialBufferSeconds:2,
          maximumInitialWaitMs:120,
          onBuffered:info=>console.info('[FORZA_NIMA_BUFFER] audio_s='+
            info.bufferedSeconds.toFixed(2)+' phrases='+info.queuedPhrases+
            ' started='+Number(info.started)),
        });
        const activeNimaBuffer=bufferedNima;
        // A provider may delay the SSE done event after the complete text
        // appears. A short idle flush avoids waiting seconds to voice the
        // final completed sentence. The timer is cancelled on further deltas,
        // turn completion, interruption, and any error.
        let firstPhraseQueued=false;
        const queueSpeech=(phrase:string)=>{
          if(activeTurnRef.current?.generation!==generation || pocketAbort.signal.aborted)return;
          if(!firstPhraseQueued){
            firstPhraseQueued=true;
            setVoiceStage('synthesizing');
            console.info('[FORZA_NIMA_LATENCY] phase=first-tts-phrase-queued clientMs='+
              Math.round(performance.now()-turnStartedAt)+' turn='+generation+' chars='+phrase.length);
          }
          activeNimaBuffer.add(phrase);
        };
        const onTextChunk=(_chunk:string,fullText:string)=>{
          if(activeTurnRef.current?.generation!==generation || pocketAbort.signal.aborted)return;
          reply=callPlainText.push(fullText);
          if(!firstTextDelivered&&reply.trim()){
            firstTextDelivered=true;
            console.info('[FORZA_LATENCY] phase=first-text turn='+generation+
              ' clientMs='+Math.round(performance.now()-turnStartedAt));
            setVoicePending(true);
          }
          setAiText(reply);
          if(useNima){
            // Enforce monotonic SSE text; never speak a revised/duplicate
            // segment after the consumer has already heard its predecessor.
            if(terminalIdleTimer!==null){
              window.clearTimeout(terminalIdleTimer);
              terminalIdleTimer=null;
            }
            for(const phrase of phrasePlanner.push(reply))queueSpeech(phrase);
            // Flush complete held groups after a bounded provider idle, even
            // if the answer has not reached its final punctuation or SSE done.
            // Incomplete suffix words and unfinished part codes remain held.
            terminalIdleTimer=window.setTimeout(()=>{
              terminalIdleTimer=null;
              if(pocketAbort.signal.aborted||callClosedRef.current||
                 activeTurnRef.current?.generation!==generation)return;
              const completed=/[.!؟؛]\s*$/.test(reply)
                ? phrasePlanner.flushTerminalIdle()
                : phrasePlanner.flushStableIdle();
              if(completed.length){
                console.info('[FORZA_NIMA_FINAL] bounded_idle_flush=1 chars='+
                  completed.reduce((sum,phrase)=>sum+phrase.length,0));
                for(const phrase of completed)queueSpeech(phrase);
              }
            },180);
          }
        };
        try {
          const streamController=new AbortController();
          let streamTimer=window.setTimeout(()=>streamController.abort(new Error('شروع دریافت پاسخ هوش مصنوعی بیش از حد طول کشید.')),30000);
          const totalTimer=window.setTimeout(()=>streamController.abort(new Error('دریافت متن پاسخ هوش مصنوعی بیش از دو دقیقه طول کشید.')),120000);
          try{
            console.info('[FORZA_LATENCY] phase=llm_request_sent turn='+generation+
              ' endToRequestMs='+(detectedSpeechEndAtRef.current
                ? Math.round(performance.now()-detectedSpeechEndAtRef.current):-1));
            const streamRes=await fetch('/api/ai/consult-stream',{
              method:'POST',
              headers:{'Content-Type':'application/json'},
              body:JSON.stringify({
                query:resolvedUserQuery,
                history:previousHistory,
                includeAudio:false,
                mode:'forza',
                userTurnId:'call-'+callIdRef.current+'-turn-'+generation,
                responseId:'call-'+callIdRef.current+'-response-'+generation,
              }),
              signal:AbortSignal.any([streamController.signal,pocketAbort.signal]),
            });
            console.info('[FORZA_LATENCY] phase=sse_headers turn='+generation+
              ' clientMs='+Math.round(performance.now()-turnStartedAt)+
              ' http='+streamRes.status);
            const rawFinal=await consumeForzaTextStream(streamRes,(chunk,fullText)=>{
              window.clearTimeout(streamTimer);
              streamTimer=window.setTimeout(()=>streamController.abort(new Error('ارتباط متن هوش مصنوعی بیش از ۴۵ ثانیه بدون داده ماند.')),45000);
              onTextChunk(chunk,fullText);
            },(stage,info)=>{
              const code=String(info?.code||'').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,48);
              const provider=String(info?.provider||'').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,32);
              // Client and server clocks are NOT assumed synchronized. Match
              // the same turn id in Node logs to separate transport, model
              // TTFT, TTS queue, inference, WAV transfer and audio decode.
              console.info('[FORZA_TEXT_STAGE] turn='+generation+' phase=browser_'+stage+
                ' clientMs='+Math.round(performance.now()-turnStartedAt)+
                (provider?' provider='+provider:'')+(code?' code='+code:''));
            });
            reply=callPlainText.complete(rawFinal);
            if(!reply)throw new Error('forza_empty_stream');
          }finally{
            window.clearTimeout(streamTimer);
            window.clearTimeout(totalTimer);
          }
        } catch(streamError) {
          if(pocketAbort.signal.aborted||activeTurnRef.current?.generation!==generation)throw streamError;
          // Keep received subtitles, but never retry via the legacy greeting route.
          if (reply) {
            // An interrupted or incomplete SSE is not a complete answer.
            // Never send the visible partial transcript to the TTS engine.
            console.warn('[FORZA] Text stream incomplete; refusing unverified trailing speech');
            // Do not allow an incomplete source to keep playing stale queued
            // audio. History stores only WAVs actually completed before this
            // interruption, not all text displayed in the subtitle.
            playerForTurn?.cancel();
            activeTurnRef.current?.markInterrupted?.();
            throw new Error('جریان پاسخ هوش مصنوعی ناقص ماند؛ متن دریافت‌شده حفظ شد. می‌توانید سؤال را دوباره بپرسید یا ادامه دهید.');
          }
          // The stream endpoint owns provider selection and bounded recovery.
          // A second legacy request could turn a timeout into a fake greeting.
          throw streamError;
        }

        if(reply && activeTurnRef.current?.generation===generation && !pocketAbort.signal.aborted){
          setAiText(reply);
          try {
            console.info('[FORZA_LATENCY] phase=whole-answer-tts-request '+
              'clientMs='+Math.round(performance.now()-turnStartedAt)+
              ' chars='+reply.length);
            if(useNima){
              if(terminalIdleTimer!==null){
                window.clearTimeout(terminalIdleTimer);
                terminalIdleTimer=null;
              }
              const finalPhrases=phrasePlanner.complete(reply);
              console.info('[FORZA_NIMA_FINAL] coalesced_phrases='+finalPhrases.length+
                ' final_chars='+(finalPhrases.at(-1)?.length||0));
              for(const phrase of finalPhrases)queueSpeech(phrase);
              await activeNimaBuffer.finish();
              console.info('[FORZA_LATENCY] phase=nima-incremental-finished phrases='+
                activeNimaBuffer.statistics.scheduled+
                ' audio_s='+activeNimaBuffer.statistics.totalBufferedSeconds.toFixed(2)+
                ' underruns='+continuousPlayer.underrunCount);
            }else{
              heardSpeechEchoRef.current=reply;
              await playPocketFullAnswer(forzaSpokenPlainText(reply),continuousPlayer,pocketAbort.signal,
                'call-'+callIdRef.current+'-turn-'+generation);
              recordHeard(reply);
            }
            if(!callClosedRef.current&&activeTurnRef.current?.generation===generation)
              setVoiceOutputError(null);
          }catch(error:any){
            if(activeTurnRef.current?.generation===generation && !pocketAbort.signal.aborted)
              setVoiceStage('error');
            if(pocketAbort.signal.aborted || activeTurnRef.current?.generation!==generation)
              console.info('[FORZA_TTS_DIAG] stage=turn-cancelled');
            else console.warn('[FORZA_TTS_DIAG] stage=turn-failed code='+
              String(error?.message||'unknown').slice(0,100));
            if(!callClosedRef.current&&activeTurnRef.current?.generation===generation){
              const ttsCode=String(error?.message||'');
              setVoiceOutputError(
                ttsCode==='autoplay_permission_required'
                  ?'برای پخش صوت یک‌بار صفحه را لمس کنید.'
                  :ttsCode==='pocket_rate_limited_network'
                    ?'سقف درخواست صوتی این اتصال در یک دقیقه تکمیل شده است؛ متن پاسخ حفظ شده و پس از پایان محدودیت می‌توانید دوباره پخش کنید.'
                    :ttsCode==='pocket_rate_limited_turn'
                      ?'سقف قطعه‌های صوتی این پاسخ تکمیل شده است؛ متن پاسخ حفظ شده و می‌توانید دوباره آن را بخوانید.'
                      :ttsCode==='pocket_http_429'
                        ?'ظرفیت موقت سرویس صوتی تکمیل است؛ متن پاسخ حفظ شده است.'
                        :ttsCode.startsWith('pocket_http_503_')
                          ?'سرویس صدای نیما موقتاً مشغول یا در حال بازیابی است؛ متن پاسخ حفظ شده است. دوباره تلاش کنید.'
                          :'تولید یا پخش صدای FORZA انجام نشد؛ متن پاسخ همچنان نمایش داده شده است.');
            }
          }
        }
      } catch (err: any) {
        if(pocketAbort.signal.aborted||activeTurnRef.current?.generation!==generation)return;
        console.warn('[AI FORZA] Conversational turn failed:', err?.message || 'unknown');
        // A speech-recognition failure is not a TTS/playback failure.
        if (!q) setUserText(previous=>previous.trim());
        setErrorNotice(
          String(err?.message || 'پاسخ هوش مصنوعی در دسترس نیست؛ لطفاً دوباره تلاش کنید.').slice(0, 230)
        );
      } finally {
        // Cancel an in-flight private voice HTTP request if the AI turn
        // failed, the user interrupted it, or the call was closed.
        // This never stops/replaces the actual Pocket voice container.
        pocketAbort.abort();
        if(terminalIdleTimer!==null)window.clearTimeout(terminalIdleTimer);
        bufferedNima?.cancel();
        playerForTurn?.cancel();
        if(activeTurnRef.current?.generation!==generation)return;
        activeTurnRef.current=null;
        setVoiceStage('idle');
        if(continuousVoiceRef.current===playerForTurn)continuousVoiceRef.current=null;
        isAiSpeakingRef.current=false;
        setVoicePending(false);
        isProcessingTurnRef.current = false;
        turnDispatchPendingRef.current=false;
        setStatus('listening');
        setTurn('user');
        startListening();
      }
    },
    [setStatus, startListening, stopListening,interruptCurrentTurn,playPocketFullAnswer,requestPocketAudio,ensureCtx,isSpeakerMuted,ensureVoiceMode]
  );

  // Setup MediaRecorder for robust audio capture and fallback STT
  const setupMediaRecorder = useCallback(
    (stream: MediaStream) => {
      try {
        const recordingSafety=new ForzaRecordingSafety();
        let rotateCapture=false;
        const mimeType = getSupportedAudioMimeType();
        if(mediaRecorderRef.current?.state!=='recording')audioChunksRef.current = [];
        const mr = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);

        mr.ondataavailable = (e: BlobEvent) => {
          if (e.data && e.data.size > 0) {
            audioChunksRef.current.push(e.data);
            recordingSafety.observe(
              isProcessingTurnRef.current||isAiSpeakingRef.current||isManualReplayPendingRef.current,
              lastForzaPlaybackAtRef.current>0&&Date.now()-lastForzaPlaybackAtRef.current<1500);
            // Keep every WebM chunk in its original order. Once a container
            // reaches its cap, stop and restart MediaRecorder so the next
            // segment receives a fresh WebM header instead of slicing bytes.
            const maxChunks=isProcessingTurnRef.current||isAiSpeakingRef.current||isManualReplayPendingRef.current?8:160;
            if(audioChunksRef.current.length>=maxChunks&&mr.state==='recording'){
              rotateCapture=true;
              mr.stop();
            }
          }
        };

        mr.onstop = () => {
          // Ignore events from an old recorder replaced by a microphone retry.
          if (mediaRecorderRef.current !== mr) return;
          const chunks = [...audioChunksRef.current];
          audioChunksRef.current = [];
          const hadSpeech = hasSpeechSoundRef.current;
          const rejectedSpeech=rejectedRecordingRef.current||!recordingSafety.safe;
          rejectedRecordingRef.current=false;
          const safeMime=mr.mimeType||mimeType||'audio/webm';
          const wasRotation=rotateCapture;
          rotateCapture=false;
          recordingSafety.reset();

          if(wasRotation){
            if(hadSpeech&&!rejectedSpeech&&chunks.length){
              const completedSegment=new Blob(chunks,{type:safeMime});
              if(completedSegment.size>1200&&!localSttActiveRef.current){
                // Local Diba already consumes the microphone stream continuously;
                // only retain WebM for the server fallback when local STT is absent.
                // Never discard an earlier segment from a long browser-fallback turn.
                audioSegmentsRef.current.push(completedSegment);
              }
            }
            // A rotation is not a user turn boundary. Keep the live transcript
            // and VAD state, and restart with a clean container header.
            if(!callClosedRef.current&&!micMutedRef.current&&streamRef.current?.active&&mr.state==='inactive'){
              try{mr.start(250);}catch{}
            }
            return;
          }
          hasSpeechSoundRef.current = false;

          if (isProcessingTurnRef.current || isAiSpeakingRef.current || statusRef.current === 'thinking') {
            // MediaRecorder.stop() is asynchronous. Resume RAM-only monitor
            // capture after the previous turn's recorder has actually stopped.
            if(!micMutedRef.current && streamRef.current?.active && mr.state==='inactive'){
              try{mr.start(250);}catch{}
            }
            return;
          }

          // Preserve the live browser interim. Complete WebM segments are
          // available to Diba only when the browser did not produce usable text.
          const currentTranscript=(pendingTranscriptRef.current||activeTranscriptRef.current||'').trim();
          pendingTranscriptRef.current='';
          if (currentTranscript) {
            activeTranscriptRef.current='';
            const finalMime=mr.mimeType||mimeType||'audio/webm';
            const finalBlob=chunks.length?new Blob(chunks,{type:finalMime}):null;
            const audioBlobs=[...audioSegmentsRef.current];
            if(finalBlob&&finalBlob.size>1200&&!rejectedSpeech)audioBlobs.push(finalBlob);
            audioSegmentsRef.current=[];
            if(audioBlobs.length){
              void handleUserFinishedSpeaking(currentTranscript,audioBlobs,finalMime);
            }else{
              hasSpeechSoundRef.current=false;
              void handleUserFinishedSpeaking(currentTranscript);
            }
            return;
          }

          // With no server ASR, empty VAD segments are not failed requests.
          // Retain browser recognition and restart only the RAM recorder.
          if(serverSttConfiguredRef.current===false||(rejectedSpeech&&audioSegmentsRef.current.length===0)){
            audioSegmentsRef.current=[];
            vadRef.current.reset();
            if(!callClosedRef.current&&!micMutedRef.current&&streamRef.current?.active&&mr.state==='inactive'){
              try{mr.start(250);}catch{}
            }
            return;
          }
          // 2. Otherwise convert recorded audio Blob and send to /api/ai/forza-live
          const finalMime = mr.mimeType || mimeType || 'audio/webm';
          const audioBlobs=[...audioSegmentsRef.current];
          const finalBlob=chunks.length?new Blob(chunks,{type:finalMime}):null;
          if(finalBlob&&finalBlob.size>1200&&!rejectedSpeech)audioBlobs.push(finalBlob);
          audioSegmentsRef.current=[];
          if(audioBlobs.length>0&&hadSpeech){
            void handleUserFinishedSpeaking('',audioBlobs,finalMime);
          }else if(hadSpeech){
            setMicrophoneError('صدای ضبط‌شده قابل استفاده نبود؛ لطفاً دوباره نزدیک میکروفون صحبت کنید.');
          }
        };

        mediaRecorderRef.current = mr;
      } catch (mrErr) {
        console.warn('[AI FORZA] MediaRecorder initialization warning:', mrErr);
      }
    },
    [handleUserFinishedSpeaking]
  );

  const initSpeechRecognition = useCallback(() => {
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) return null;

    try {
      const rec = new SpeechRec();
      const admission=new ForzaRecognitionAdmission();
      let admissionRetry:ReturnType<typeof setTimeout>|null=null;
      let admissionSession=0;
      const canRestart=()=>!callClosedRef.current&&!micMutedRef.current&&isCallActive&&
        greetingFinishedRef.current&&!recognitionFailedRef.current&&
        !localSttRecognizerRef.current&&recognitionRef.current===rec;
      const scheduleRestart=(delay:number)=>{
        if(!canRestart()||recognitionRetryTimerRef.current!==null)return;
        recognitionRetryTimerRef.current=window.setTimeout(()=>{
          recognitionRetryTimerRef.current=null;
          if(!canRestart()||isRecognitionActiveRef.current||recognitionStartPendingRef.current)return;
          startWithWatchdog();
        },delay);
      };
      const startWithWatchdog=()=>{
        if(!canRestart()||isRecognitionActiveRef.current||recognitionStartPendingRef.current)return;
        recognitionStartPendingRef.current=true;
        try{
          rec.start();
          if(recognitionStartWatchdogRef.current!==null)
            window.clearTimeout(recognitionStartWatchdogRef.current);
          recognitionStartWatchdogRef.current=window.setTimeout(()=>{
            recognitionStartWatchdogRef.current=null;
            if(recognitionRef.current===rec&&!isRecognitionActiveRef.current&&
               !callClosedRef.current&&!micMutedRef.current&&!recognitionFailedRef.current){
              recognitionStartPendingRef.current=false;
              scheduleRestart(450);
            }
          },1500);
        }catch(error:any){
          recognitionStartPendingRef.current=false;
          if(error?.name==='InvalidStateError'){
            scheduleRestart(350);
            return;
          }
          recognitionFailedRef.current=true;
          webSpeechFailedRef.current=true;
          setMicrophoneError('تشخیص گفتار دوباره متصل نشد؛ روی «اتصال دوباره میکروفون» بزنید.');
        }
      };
      recognitionStartRef.current=()=>startWithWatchdog();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = 'fa-IR';

      rec.onstart = () => {
        if(callClosedRef.current||micMutedRef.current||recognitionRef.current!==rec){
          try{rec.abort();}catch{}
          return;
        }
        recognitionSessionBaseRef.current=activeTranscriptRef.current.trim();
        recognitionFailedRef.current=false;
        webSpeechFailedRef.current=false;
        setMicrophoneError(null);
        isRecognitionActiveRef.current = true;
        recognitionStartPendingRef.current=false;
        if(recognitionStartWatchdogRef.current!==null)
          window.clearTimeout(recognitionStartWatchdogRef.current);
        recognitionStartWatchdogRef.current=null;
        console.info('[FORZA_STT_LIFECYCLE] event=start');
        admission.reset();admissionSession++;
        if(admissionRetry)clearTimeout(admissionRetry);admissionRetry=null;
        recognitionConsumedInterimRef.current={};
        recognitionCheckpointRef.current={count:0,interim:{}};
        recognitionResultCountRef.current=0;
        recognitionConsumedCountRef.current=0;
      };

      rec.onresult = (event: any) => {
        if(callClosedRef.current||micMutedRef.current||recognitionRef.current!==rec)return;
        if(admissionRetry)clearTimeout(admissionRetry);admissionRetry=null;
        const rawResults=event.results;
        const retryExpired=event.forzaAdmissionUntil && Date.now()>=event.forzaAdmissionUntil;
        const playback=isProcessingTurnRef.current||isAiSpeakingRef.current||isManualReplayPendingRef.current;
        const admitted=admission.filter(event.results,(words,final)=>{
          if(retryExpired||likelySpeakerEcho(words))return 'reject';
          const decision=speechAdmissionRef.current.decide(words,final,playback,Date.now());
          if(new URLSearchParams(window.location.search).get('forzaVoiceDiagnostics')==='1')
            console.info('[FORZA_ADMISSION]',decision,JSON.stringify(speechAdmissionRef.current.diagnostics(Date.now())));
          return decision;
        });
        if(admitted.waiting&&!retryExpired){
          const session=admissionSession;
          const until=event.forzaAdmissionUntil||Date.now()+400;
          admissionRetry=setTimeout(()=>{
            admissionRetry=null;
            if(session===admissionSession)rec.onresult?.({results:rawResults,forzaAdmissionUntil:until});
          },80);
        }
        if(admitted.rejected)rejectedRecordingRef.current=true;
        event={...event,results:admitted.results};
        // Chrome's results include earlier FINAL words on every event.
        // Rebuild all segments; processing only resultIndex loses sentences.
        const total=Number(event.results?.length||0);
        if(total<recognitionConsumedCountRef.current){
          recognitionConsumedCountRef.current=0;
          recognitionConsumedInterimRef.current={};
        }
        recognitionResultCountRef.current=total;
        recognitionCheckpointRef.current=checkpointForzaRecognition(event.results);
        const recognized = extractPersianSpeechSince(event.results,recognitionConsumedCountRef.current,recognitionConsumedInterimRef.current);
        console.info('[FORZA_STT_LIFECYCLE] event=result total='+total+
          ' consumed='+recognitionConsumedCountRef.current+' chars='+recognized.text.length+
          ' interim='+Number(recognized.hasInterim));
        const currentSpeech = recognized.text;
        if(!currentSpeech.trim())return;
        if(!admitted.changed)return;
        recognitionRetryRef.current=0;
        recognitionFailedRef.current=false;
        webSpeechFailedRef.current=false;
        if(recognitionRetryTimerRef.current!==null)
          window.clearTimeout(recognitionRetryTimerRef.current);
        recognitionRetryTimerRef.current=null;
        setMicrophoneError(null);
        setErrorNotice(null);
        if(isProcessingTurnRef.current||isAiSpeakingRef.current||isManualReplayPendingRef.current){
          // RMS alone cannot distinguish the loudspeaker from a person.
          // Require actual STT words and reject likely self-echo.
          // Recent near-field VAD evidence was checked above. Keep the short
          // timestamp grace because final STT can arrive after VAD resets.
          if(likelySpeakerEcho(currentSpeech)){
            // Retire finalized echo so it cannot contaminate the next user
            // utterance after playback finishes. Keep interim slots revisable.
            let cursor=recognitionConsumedCountRef.current;
            while(cursor<total && event.results[cursor]?.isFinal)cursor++;
            recognitionConsumedCountRef.current=cursor;
            console.info('[FORZA_STT] source=browser echo_candidate_ignored=1');
            return;
          }
          interruptRequestRef.current();
        }
        const mergedSpeech=appendForzaSpeechSegment(recognitionSessionBaseRef.current,currentSpeech);
        if(!recognized.hasInterim&&forzaTurnIntent(currentSpeech)==='stop'){
          void handleUserFinishedSpeaking(currentSpeech);
          return;
        }
        stopAcknowledgementRef.current?.cancel();
        if (mergedSpeech) {
          if(mergedSpeech!==activeTranscriptRef.current ||
             speechInterimRef.current!==recognized.hasInterim){
            lastTranscriptChangedAtRef.current=Date.now();
          }
          speechInterimRef.current = recognized.hasInterim;
          hasSpeechSoundRef.current = true;
          activeTranscriptRef.current = mergedSpeech;
          setUserText(composeForzaSessionTranscript(sessionTranscriptRef.current,mergedSpeech));
          setStatus('listening');
          setTurn('user');
          setIsUserSpeaking(true);

          if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
          const tryFinalize=()=>{
            silenceTimerRef.current=null;
            if(isAiSpeakingRef.current||isProcessingTurnRef.current||
               statusRef.current!=='listening'||micMutedRef.current)return;
            const candidate=activeTranscriptRef.current.trim();
            if(!candidate)return;
            const wait=forzaTurnRemainingWaitMs(
              candidate,speechInterimRef.current,
              Date.now()-lastTranscriptChangedAtRef.current,
              vadRef.current.heardSpeech?vadRef.current.silenceDuration(Date.now()):null);
            if(wait>0){
              silenceTimerRef.current=window.setTimeout(tryFinalize,Math.max(80,wait));
              return;
            }
            detectedSpeechEndAtRef.current=vadRef.current.heardSpeech
              ? performance.now()-vadRef.current.silenceDuration(Date.now()) : 0;
            console.info('[FORZA_LATENCY] phase=browser_stt_turn_end chars='+candidate.length+
              ' endToSttFinalMs='+(detectedSpeechEndAtRef.current
                ? Math.round(performance.now()-detectedSpeechEndAtRef.current):-1));
            sessionTranscriptRef.current=appendForzaSessionTurn(sessionTranscriptRef.current,candidate);
            pendingCommittedTranscriptRef.current=candidate;
            setUserText(sessionTranscriptRef.current);
            pendingTranscriptRef.current=candidate;
            activeTranscriptRef.current='';
            recognitionSessionBaseRef.current='';
            lastTranscriptChangedAtRef.current=0;
            setIsUserSpeaking(false);
            const recorder=mediaRecorderRef.current;
            if(recorder?.state==='recording'){
              recorder.stop();
            }else{
              pendingTranscriptRef.current='';
              hasSpeechSoundRef.current=false;
              void handleUserFinishedSpeaking(candidate);
            }
          };
          silenceTimerRef.current=window.setTimeout(tryFinalize,Math.max(40,
            forzaTurnRemainingWaitMs(mergedSpeech,recognized.hasInterim,
              Date.now()-lastTranscriptChangedAtRef.current,
              vadRef.current.heardSpeech?vadRef.current.silenceDuration(Date.now()):null)));
        }
      };

      rec.onerror = (e: any) => {
        if(admissionRetry)clearTimeout(admissionRetry);admissionRetry=null;
        if(callClosedRef.current||recognitionRef.current!==rec)return;
        const error = e?.error;
        recognitionStartPendingRef.current=false;
        if(recognitionStartWatchdogRef.current!==null)
          window.clearTimeout(recognitionStartWatchdogRef.current);
        recognitionStartWatchdogRef.current=null;
        console.warn('[AI FORZA SpeechRecognition] Status:', error);
        const retryDelay=forzaRecognitionRetryDelay(String(error),recognitionRetryRef.current);
        if(retryDelay!==null && !callClosedRef.current && !micMutedRef.current){
          recognitionFailedRef.current=true;
          webSpeechFailedRef.current=true;
          recognitionRetryRef.current++;
          if(recognitionRetryTimerRef.current!==null)window.clearTimeout(recognitionRetryTimerRef.current);
          try{rec.abort();}catch{}
          setMicrophoneError('ارتباط تشخیص گفتار لحظه‌ای قطع شد؛ در حال اتصال دوباره هستیم.');
          recognitionRetryTimerRef.current=window.setTimeout(()=>{
            recognitionRetryTimerRef.current=null;
            if(callClosedRef.current||micMutedRef.current||!isCallActive||
               localSttRecognizerRef.current||recognitionRef.current!==rec)return;
            recognitionFailedRef.current=false;
            webSpeechFailedRef.current=false;
            startWithWatchdog();
          },retryDelay);
          return;
        }
        if (['network','not-allowed','service-not-allowed','audio-capture','language-not-supported'].includes(error)) {
          webSpeechFailedRef.current = true;
          recognitionFailedRef.current=true;
          // Preserve the existing provider behind /api/ai/forza-live.
          // The microphone recorder continues; only its finalized audio
          // will be sent if the browser recognizer is unavailable.
          setMicrophoneError('تشخیص زنده گفتار مرورگر در دسترس نیست. اگر سرویس مستقل STT روی سرور تنظیم نشده باشد، سؤال را با دکمه «تایپ پیام متنی» وارد کنید.');
        }
      };

      rec.onend = () => {
        if(admissionRetry)clearTimeout(admissionRetry);admissionRetry=null;
        if(recognitionRef.current!==rec)return;
        isRecognitionActiveRef.current=false;
        recognitionStartPendingRef.current=false;
        if(recognitionStartWatchdogRef.current!==null)
          window.clearTimeout(recognitionStartWatchdogRef.current);
        recognitionStartWatchdogRef.current=null;
        console.info('[FORZA_STT_LIFECYCLE] event=end failed='+Number(recognitionFailedRef.current));
        // End is normal (including no-speech). Keep the recognizer alive during
        // Nima/manual playback too, otherwise barge-in silently disappears.
        if(!canRestart()||recognitionRetryTimerRef.current!==null)return;
        scheduleRestart(200);
      };

      return rec;
    } catch {
      return null;
    }
  }, [handleUserFinishedSpeaking, isCallActive, isMicMuted, setStatus,startDibaTurn]);

  // Request mic access on entry; only start active transcription after greeting.
  const initializeMicrophone = useCallback(async () => {
    if(callClosedRef.current)return;
    const microphoneGeneration=++microphoneGenerationRef.current;
    setMicrophoneError(null);
    try {
      if (!window.isSecureContext) throw new Error('insecure_origin');
      if (!navigator.mediaDevices?.getUserMedia) throw new Error('unsupported');
      // Resuming AudioContext from an explicit click also unlocks analyser VAD.
      // Never await AudioContext.resume() before getUserMedia: Chrome can
      // suspend it until a user gesture and otherwise block mic acquisition.
      const ctx=ensureCtx();
      const stream=await navigator.mediaDevices.getUserMedia({audio:{
        echoCancellation:true,noiseSuppression:true,autoGainControl:false,channelCount:1,
      }});
      if(callClosedRef.current || microphoneGeneration!==microphoneGenerationRef.current){
        stream.getTracks().forEach(track=>track.stop());
        return;
      }
      streamRef.current?.getTracks().forEach(track=>{track.onended=null;track.stop();});
      streamRef.current=stream;
      micContextWarningRef.current=false;
      speechAdmissionRef.current.reset();rejectedRecordingRef.current=false;
      vadRef.current.reset();
      lastMicActivityRef.current=0;
      for (const track of stream.getAudioTracks()) {
        track.onended=()=>setMicrophoneError('ارتباط میکروفون قطع شد. پس از وصل‌کردن میکروفون، صفحه را بازخوانی کنید.');
      }
      audioEvidenceCleanupRef.current?.();audioEvidenceCleanupRef.current=null;
      if(ctx){
        micSourceNodeRef.current?.disconnect();
        const source=ctx.createMediaStreamSource(stream);
        const analyser=ctx.createAnalyser();
        analyser.fftSize=512;analyser.smoothingTimeConstant=0.6;
        source.connect(analyser);
        micSourceNodeRef.current=source;
        micAnalyserRef.current=analyser;
        void attachForzaAudioEvidence(ctx,source,(rms,at)=>{
          if(callClosedRef.current||microphoneGeneration!==microphoneGenerationRef.current||micMutedRef.current)return;
          speechAdmissionRef.current.sample(rms,at,
            isProcessingTurnRef.current||isAiSpeakingRef.current||isManualReplayPendingRef.current);
        },()=>{
          if(microphoneGeneration!==microphoneGenerationRef.current)return;
          audioEvidenceCleanupRef.current=null;speechAdmissionRef.current.reset();
        }).then(dispose=>{
          if(callClosedRef.current||microphoneGeneration!==microphoneGenerationRef.current){dispose();return;}
          speechAdmissionRef.current.reset();audioEvidenceCleanupRef.current=dispose;
        }).catch(()=>{/* Older browsers retain the conservative analyser fallback. */});
      }
      if(mediaRecorderRef.current?.state==='recording') mediaRecorderRef.current.stop();
      localSttNodeRef.current?.disconnect();localSttSinkRef.current?.disconnect();
      localSttNodeRef.current=null;localSttSinkRef.current=null;
      attachLocalStt();
      setupMediaRecorder(stream);
      // Warm the free local Diba/Vosk browser recognizer in the background on
      // devices with enough CPU headroom. Chrome keeps transcribing immediately
      // until the model is ready; low-power/save-data devices stay on Chrome.
      const dibaCpuCount=Number(navigator.hardwareConcurrency||0);
      const dibaDeviceMemory=Number((navigator as any).deviceMemory||0);
      const dibaSaveData=Boolean((navigator as any).connection?.saveData);
      // Keep the WASM model off low-end phones and memory-constrained browsers.
      const dibaHasHeadroom=dibaCpuCount>=4&&(dibaDeviceMemory>=4||(!dibaDeviceMemory&&dibaCpuCount>=8));
      if(dibaHasHeadroom&&!dibaSaveData&&!localSttModelRef.current&&!localSttModelLoadingRef.current){
        localSttModelLoadingRef.current=true;
        setLocalSttStatus('loading');
        setServerSttLabel('در حال آماده‌سازی دایبا محلی · متن مرورگر فعال است');
        void loadDibaSttModel().then(model=>{
          if(callClosedRef.current){model.terminate?.();return;}
          localSttModelRef.current=model;
          attachLocalStt();
          setLocalSttStatus('ready');
          setServerSttLabel('دایبا محلی آماده است · تشخیص زنده');
          console.info('[FORZA_STT] provider=diba-browser ready=1');
          // Switch only at a clean boundary. If the customer is mid-sentence,
          // keep Chrome until the current turn has been delivered.
          if(greetingFinishedRef.current&&!activeTranscriptRef.current.trim()&&
             !vadRef.current.heardSpeech){
            startListening(true);
          }
        }).catch(error=>{
          if(callClosedRef.current)return;
          setLocalSttStatus('fallback');
          setServerSttLabel(serverSttConfiguredRef.current
            ? 'دایبا سرور آماده است · متن زنده مرورگر'
            : 'متن زنده مرورگر فعال است');
          console.warn('[FORZA_STT] provider=diba-browser unavailable=1 code='+
            String((error as any)?.message||'model_error').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,40));
        }).finally(()=>{localSttModelLoadingRef.current=false;});
      }
      if(recognitionRetryTimerRef.current!==null)window.clearTimeout(recognitionRetryTimerRef.current);
      recognitionRetryTimerRef.current=null;
      if(recognitionStartWatchdogRef.current!==null)window.clearTimeout(recognitionStartWatchdogRef.current);
      recognitionStartWatchdogRef.current=null;
      recognitionStartPendingRef.current=false;
      recognitionStartRef.current=()=>{};
      recognitionRetryRef.current=0;
      const previousRecognizer=recognitionRef.current;
      if(previousRecognizer){previousRecognizer.onend=null;previousRecognizer.onerror=null;previousRecognizer.onresult=null;try{previousRecognizer.abort();}catch{}}
      recognitionFailedRef.current=false;
      webSpeechFailedRef.current=false;
      isRecognitionActiveRef.current=false;
      recognitionRef.current=initSpeechRecognition();
      if(!recognitionRef.current&&!localSttRecognizerRef.current){
        recognitionFailedRef.current=true;webSpeechFailedRef.current=true;
        setMicrophoneError('تشخیص گفتار در این مرورگر راه‌اندازی نشد؛ با Chrome و مجوز میکروفون دوباره امتحان کنید.');
      }
      if(greetingFinishedRef.current && !micMutedRef.current) startListening();
    } catch(error:any) {
      if(callClosedRef.current || microphoneGeneration!==microphoneGenerationRef.current)return;
      setMicrophoneError(error?.message==='insecure_origin'
        ? 'برای استفاده از میکروفون، FORZA را با HTTPS معتبر باز کنید؛ آدرس HTTP روی IP عمومی امن نیست.'
        : error?.name==='NotAllowedError' || error?.name==='PermissionDeniedError'
        ? 'اجازه میکروفون رد شده است. Microphone را در تنظیمات سایت Allow کنید؛ سپس صفحه را بازخوانی کنید.'
        : 'میکروفون متصل نشد. میکروفون پیش‌فرض و مجوز مرورگر را بررسی کنید.');
    }
  },[ensureCtx,setupMediaRecorder,initSpeechRecognition,startListening,attachLocalStt]);

  // STT prefers same-origin local Diba/Vosk partials on capable devices,
  // keeps browser recognition active during warmup, and retains server Diba
  // as a final fallback. Low-power/save-data devices stay on browser STT.

  // Discover the optional transcription fallback independently of the
  // text AI provider. Browser streaming STT still works when this is false.
  // A failed discovery does not disable the existing compatibility path.
  useEffect(()=>{
    const controller=new AbortController();
    void fetch('/api/ai/forza-stt-info',{signal:controller.signal,cache:'no-store'})
      .then(async response=>response.ok?await response.json():null)
      .then((info:{serverSttConfigured?:boolean;serverSttProvider?:string;serverSttReady?:boolean}|null)=>{
        if(controller.signal.aborted||typeof info?.serverSttConfigured!=='boolean')return;
        // The project explicitly avoids Gemini speech recognition. Only a
        // ready local Diba/Vosk worker may trigger a server-audio round trip.
        const dibaReady=info.serverSttProvider==='diba'&&
          info.serverSttConfigured===true&&info.serverSttReady===true;
        serverSttConfiguredRef.current=dibaReady;
        setServerSttLabel(localSttModelRef.current
          ? 'دایبا محلی آماده است · تشخیص زنده'
          : localSttModelLoadingRef.current
            ? 'در حال آماده‌سازی دایبا محلی · متن مرورگر فعال است'
            : dibaReady
              ? 'دایبا سرور آماده است'
              : info.serverSttProvider==='diba'
                ? 'دایبا در دسترس نیست؛ متن زنده مرورگر'
                : 'دایبا تنظیم نشده؛ متن زنده مرورگر');
      })
      .catch(()=>{
        if(!controller.signal.aborted){serverSttConfiguredRef.current=false;setServerSttLabel('وضعیت دایبا نامشخص؛ متن زنده مرورگر');}
      });
    return ()=>controller.abort();
  },[]);

  // Acquire permission while the particle animation forms; audio input stays
  // muted for transcription until the greeting has finished.
  useEffect(() => {
    if (micAutoStartedRef.current) return;
    micAutoStartedRef.current = true;
    void initializeMicrophone();
  }, [initializeMicrophone]);

  // Start only after the avatar confirms 100% of particles have formed.
  // Never listen to the introduction or silently skip an autoplay denial.
  useEffect(() => {
    if (!particlesFormed || greetingStartedRef.current) return;
    greetingStartedRef.current=true;
    let active=true;
    setStatus('idle'); setTurn('ai'); setGreetingPhase('preparing');
    setDisplayedAi(GREETING_TEXT);
    if(!historyRef.current.length)historyRef.current.push({role:'model',text:GREETING_TEXT});
    void speakText(GREETING_TEXT).then(()=>{
      if(!active)return;
      setVoiceOutputError(null);
      greetingFinishedRef.current=true;
      setGreetingPhase('complete');
      setStatus('listening');setTurn('user');
      startListening();
    }).catch((e:any)=>{
      if(!active)return;
      const autoplayDenied = e?.message === 'autoplay_permission_required' ||
        e?.message === 'browser_tts_failed';
      console.warn('[FORZA] Greeting audio unavailable',e?.message||'audio_error');
      if (autoplayDenied) {
        setGreetingPhase('needs-permission');
        setAutoplayBlocked(true);
        setVoiceOutputError('مرورگر پخش خودکار را محدود کرده است؛ برای ادامه یک بار روی صفحه کلیک کنید.');
        return;
      }
      // Do not listen before a complete audible greeting.
      greetingFinishedRef.current=false;
      setGreetingPhase('needs-permission');
      setStatus('idle');
      setTurn('ai');
      setVoiceOutputError('صدای خوشامدگویی فورزا پخش نشد. روی «شروع مکالمه» بزنید تا دوباره امتحان شود.');
    });
    return ()=>{
      active=false;
      greetingStartedRef.current=false;
      greetingFinishedRef.current=false;
      if(silenceTimerRef.current)clearTimeout(silenceTimerRef.current);
      if(recognitionRetryTimerRef.current!==null)window.clearTimeout(recognitionRetryTimerRef.current);
      stopListening();
      streamRef.current?.getTracks().forEach(track=>track.stop());
      streamRef.current=null;
      audioEvidenceCleanupRef.current?.();audioEvidenceCleanupRef.current=null;
    speechAdmissionRef.current.reset();
    localSttRecognizerRef.current?.remove?.();localSttRecognizerRef.current=null;
      localSttNodeRef.current?.disconnect();localSttSinkRef.current?.disconnect();
      localSttNodeRef.current=null;localSttSinkRef.current=null;
      stopAudio();
    };
  // A scene starts once. Changing TTS/recognition callbacks must not tear down
  // the stream mid-greeting or permanently disable the microphone.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[particlesFormed]);

  // One teardown for explicit hangup AND route changes, including exit before
  // the particle formation/greeting effect has ever acquired its cleanup.
  const releaseCallResources = useCallback(() => {
    callClosedRef.current=true;
    stopAcknowledgementRef.current?.dispose();stopAcknowledgementRef.current=null;
    playbackEchoHistoryRef.current.clear();
    ++microphoneGenerationRef.current;
    micAutoStartedRef.current=false;
    activeTurnRef.current?.abort.abort(new Error('forza_call_closed'));
    activeTurnRef.current=null;
    if(silenceTimerRef.current)clearTimeout(silenceTimerRef.current);
    silenceTimerRef.current=null;
    if(recognitionRetryTimerRef.current!==null)window.clearTimeout(recognitionRetryTimerRef.current);
    recognitionRetryTimerRef.current=null;
    if(recognitionStartWatchdogRef.current!==null)window.clearTimeout(recognitionStartWatchdogRef.current);
    recognitionStartWatchdogRef.current=null;
    recognitionStartPendingRef.current=false;
    recognitionStartRef.current=()=>{};
    const recognition=recognitionRef.current;
    recognitionRef.current=null;
    if(recognition){
      recognition.onresult=null;recognition.onerror=null;recognition.onend=null;
      try{recognition.abort();}catch{}
    }
    isRecognitionActiveRef.current=false;
    const recorder=mediaRecorderRef.current;
    mediaRecorderRef.current=null;
    if(recorder){
      recorder.ondataavailable=null;recorder.onstop=null;recorder.onerror=null;
      try{if(recorder.state!=='inactive')recorder.stop();}catch{}
    }
    const stream=streamRef.current;
    streamRef.current=null;
    stream?.getTracks().forEach(track=>{track.onended=null;track.stop();});
    audioEvidenceCleanupRef.current?.();audioEvidenceCleanupRef.current=null;
    speechAdmissionRef.current.reset();
    const localRecognizer=localSttRecognizerRef.current;localSttRecognizerRef.current=null;
    localSttAdmissionRef.current=null;localSttActiveRef.current=false;localSttFinalRef.current='';
    turnDispatchPendingRef.current=false;
    try{localRecognizer?.remove?.();}catch{}
    const localModel=localSttModelRef.current;localSttModelRef.current=null;
    localSttModelLoadingRef.current=false;
    try{localModel?.terminate?.();}catch{}
    for(const node of [localSttNodeRef.current,localSttSinkRef.current,
      micSourceNodeRef.current,micAnalyserRef.current,audioSourceNodeRef.current,
      analyserRef.current,gainNodeRef.current]){
      try{node?.disconnect();}catch{}
    }
    localSttNodeRef.current=null;localSttSinkRef.current=null;
    micSourceNodeRef.current=null;micAnalyserRef.current=null;
    audioSourceNodeRef.current=null;analyserRef.current=null;gainNodeRef.current=null;
    if(animFrameAudioRef.current!==null)cancelAnimationFrame(animFrameAudioRef.current);
    animFrameAudioRef.current=null;
    stopAudio();
    const context=ctxRef.current;
    ctxRef.current=null;
    if(context && context.state!=='closed')void context.close().catch(()=>{});
    historyRef.current=[];
    sessionTranscriptRef.current='';
    pendingCommittedTranscriptRef.current='';
    pendingHistoryTurnRef.current='';
    audioChunksRef.current=[];
    audioSegmentsRef.current=[];
    isProcessingTurnRef.current=false;
  },[stopAudio]);

  useEffect(()=>()=>releaseCallResources(),[releaseCallResources]);

  const endCall = useCallback(() => {
    releaseCallResources();
    setIsCallActive(false);
    onClose?.();
  }, [onClose,releaseCallResources]);

  const submitUserText = (text: string) => {
    if (!greetingFinishedRef.current || !text.trim()) return false;
    detectedSpeechEndAtRef.current=0; // typed turns have no acoustic end
    void handleUserFinishedSpeaking(text);
    return true;
  };

  const toFarsiDigits = (n: number | string) => {
    const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return n.toString().replace(/[0-9]/g, w => farsiDigits[+w]);
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60)
      .toString()
      .padStart(2, '0');
    const r = (s % 60).toString().padStart(2, '0');
    return toFarsiDigits(`${m}:${r}`);
  };

  // Keep the full customer transcript visible beside the assistant response.
  // The same scrollable card retains both sides of the live conversation.
  const showCustomerTranscript = Boolean(userText.trim());
  const showAssistantTranscript = Boolean(displayedAi);

  return (
    <main
      ref={shell}
      className="forza-stage"
      dir="ltr"
      onClick={() => {
        if (autoplayBlocked) {
          unlockAudio();
        }
      }}
      onDoubleClick={e => {
        if ((e.target as HTMLElement).tagName === 'CANVAS') setClean(c => !c);
      }}
    >
      {/* The heavy WebGL engine is split from the voice controller; the page paints first. */}
      <Suspense fallback={<div className="forza-avatar-fallback" aria-hidden="true" />}>
        <ParticleAvatar
          ref={avatarRef}
          paused={paused}
          mode={avatarMode}
          intensity={avatarIntensity}
          audioLevel={audioLevel}
          quality={quality}
          background={true}
          backgroundSpeed={speed}
          restartKey={revision}
          onError={message => setErrorNotice(message)}
          onStats={s => setStats(prev => ({ ...prev, ...s }))}
          onFormed={() => setParticlesFormed(true)}
        />
      </Suspense>

      {/* Hidden HTML5 audio element for direct, crystal-clear Persian TTS streaming */}
      <audio ref={audioElRef} className="hidden" playsInline preload="auto" />

      {/* 2. HUD Cybernetic Overlay (toggleable with H or signal button) */}
      {!clean && (
        <div className="forza-hud" aria-hidden="true">
          <i className="hud-corner tl" />
          <i className="hud-corner tr" />
          <i className="hud-corner bl" />
          <i className="hud-corner br" />

          {/* Top-Right FORZA Lockup & Audio Spectrum */}
          <div className="hud-block hud-top-right">
            <div className="flex items-center gap-3 justify-end">
              <div>
                <div className="hud-title text-white tracking-widest text-base font-black">- FORZA</div>
                <div className="hud-dim text-[10px] tracking-wider text-[#dee2e5]/80">
                  HUMAN SYSTEMS / 001 · {stats.particles ? `${stats.particles.toLocaleString('en')} PARTICLES` : 'PARTICLES —'}
                </div>
              </div>
              <div className="bars h-4">
                <span />
                <span />
                <span />
                <span />
                <span />
              </div>
            </div>
          </div>

          {/* Top-Left Telemetry Status directly under exit button */}
          <div className="hud-block hud-top-left">
            <div className="hud-dim text-[10px] tabular-nums text-[#dee2e5]/70 tracking-wider font-mono">
              {stats.tier} · {stats.fps!==null ? `${stats.fps} FPS` : 'FPS —'} · {formatTime(seconds)}
            </div>
          </div>

          {/* Left Brand Procedural Identity Label */}
          <div className="procedural-label">
            <span>PROCEDURAL IDENTITY</span>
            <strong>Built from<br />light</strong>
          </div>

          {/* Bottom-Left Metric: Sync % & Realtime status */}
          <div className="hud-block hud-bottom-left">
            <div className="text-[11px] text-[#dee2e5] font-mono">
              SYNC <b className="text-white">—</b>
            </div>
            <div className="hud-dim text-[10px] text-[#dee2e5]/70 font-mono tracking-wider">
              PARTICLE MESH · REALTIME GPU
            </div>
          </div>

          {/* Subtle light scan line */}
          <div className="scan" />
        </div>
      )}

      {/* Top Header Exit Call Button */}
      <button
        type="button"
        onClick={endCall}
        className="forza-exit-call-button absolute top-5 left-6 z-40 flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-red-950/80 hover:bg-red-900 border border-red-500/60 hover:border-red-400 text-white shadow-xl shadow-black/60 backdrop-blur-md transition-all active:scale-95 group cursor-pointer"
        aria-label="پایان مکالمه و خروج"
        title="پایان مکالمه هوشمند FORZA"
        dir="rtl"
      >
        <div className="w-5 h-5 rounded-full bg-red-600 flex items-center justify-center text-white group-hover:bg-red-500 transition-colors">
          <PhoneOff size={11} className="text-white" />
        </div>
        <span className="font-bold text-xs tracking-wide">خروج</span>
      </button>

      {/* Top Center Signal / HUD Toggle */}
      <button
        className="signal-toggle"
        onClick={() => setClean(c => !c)}
        aria-label={clean ? 'نمایش HUD' : 'مخفی‌سازی HUD'}
        title="تغییر نمایش HUD و جزئیات (کلید H)"
      >
        <span />
        <span />
        <span />
        <span />
      </button>

      {/* 3. Persian Voice Subtitles & Interaction Pill matching screenshot layout */}
      <div
        dir="rtl"
        className="forza-conversation-panel absolute bottom-3 right-3 sm:bottom-20 sm:right-10 w-[calc(100%-1.5rem)] sm:w-[min(36vw,30rem)] max-h-[40dvh] sm:max-h-[55dvh] overflow-y-auto max-w-[34rem] z-30 flex flex-col gap-3 pointer-events-none"
      >
        {/* Turn Status Pill & Mic / Speaker Controls */}
        <div className="forza-status-dock self-end inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/88 border border-white/15 backdrop-blur-xl shadow-lg text-xs pointer-events-auto transition-all forza-persian-label">
          <span className="font-semibold text-white text-[12px] sm:text-[13px] leading-6">
            {turn === 'user'
              ? 'فورزا گوش می‌دهد؛ صحبتتان را کامل کنید'
              : greetingPhase === 'needs-permission'
              ? 'برای شروع باید صدای خوشامدگویی پخش شود'
              : status === 'speaking' && isSpeakerMuted
              ? 'صدای فورزا بی‌صداست'
              : status === 'speaking' && voiceStage === 'playing'
              ? 'AI FORZA در حال صحبت...'
              : greetingPhase === 'preparing'
              ? 'AI FORZA در حال خوشامدگویی...'
              : voiceStage === 'buffering'
              ? 'در انتظار ادامه صدا...'
              : voiceStage === 'synthesizing'
              ? 'در حال تولید صدا...'
              : voiceStage === 'text'
              ? 'در انتظار پاسخ فورزا...'
              : status === 'thinking' && voicePending
              ? 'در انتظار پخش صوت...'
              : status === 'thinking'
              ? 'در انتظار پاسخ فورزا...'
              : 'AI FORZA آماده می‌شود...'}
          </span>
          <span
            className={`w-2 h-2 rounded-full ${
              turn === 'user'
                ? 'bg-white shadow-[0_0_8px_#ffffff]'
                : status === 'thinking'
                ? 'bg-[#e06518] shadow-[0_0_8px_#e06518] animate-pulse'
                : 'bg-[#e06518] shadow-[0_0_8px_#e06518]'
            }`}
          />
          {(isProcessingTurnRef.current || isAiSpeakingRef.current || voicePending) && greetingPhase === 'complete' && (
            <button type="button"
              onClick={interruptCurrentTurn}
              className="p-1 rounded-md text-[#dee2e5]/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="توقف فوری پاسخ و ادامه شنیدن صدای مشتری"
              aria-label="توقف پاسخ فورزا">
              <Square size={13} fill="currentColor" />
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              setIsSpeakerMuted(prev => {
                const next = !prev;
                if (audioElRef.current) audioElRef.current.muted = next;
                return next;
              });
            }}
            className={`mr-1 p-1 rounded-md transition-colors cursor-pointer ${
              isSpeakerMuted ? 'text-red-400 hover:bg-red-500/20' : 'text-[#dee2e5]/70 hover:text-white hover:bg-white/10'
            }`}
            title={isSpeakerMuted ? 'خروج از حالت بی‌صدا' : 'بی‌صدا کردن صدای گوینده'}
          >
            {isSpeakerMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
          </button>
          <button
            type="button"
            onClick={() => { if(greetingPhase==='complete')void replayAiVoice(); else unlockAudio(); }}
            disabled={!aiText.trim() || status === 'speaking'}
            className="p-1 rounded-md text-[#dee2e5]/70 hover:text-white hover:bg-white/10 disabled:opacity-40"
            title="خواندن دوباره پاسخ فورزا"
            aria-label="خواندن دوباره پاسخ فورزا">
            <RotateCcw size={14}/>
          </button>
          <button
            type="button"
            onClick={() => setIsMicMuted(prev => {
              const next = !prev;
              micMutedRef.current = next;
              if (next) stopListening();
              else if (greetingFinishedRef.current) startListening();
              return next;
            })}
            className={`p-1 rounded-md cursor-pointer ${isMicMuted ? 'text-red-400' : 'text-[#dee2e5]/70 hover:text-white'}`}
            title={isMicMuted ? 'روشن کردن میکروفون' : 'بی‌صدا کردن میکروفون'}>
            {isMicMuted ? <MicOff size={14} /> : <Mic size={14} />}
          </button>
          <button
            type="button"
            onClick={() => setShowTextInput(!showTextInput)}
            className="p-1 rounded-md text-[#dee2e5]/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="تایپ پیام متنی"
          >
            <MessageSquare size={13} />
          </button>
        </div>

        {!clean && (
          <div role="status" dir="rtl" className="forza-voice-meta pointer-events-none self-end text-[10px] text-[#dee2e5]/70">
            صدای فورزا: {activeVoiceLabel} · تشخیص گفتار: {serverSttLabel}
          </div>
        )}
        {microphoneError && (
          <div role="alert" className="pointer-events-auto self-end flex max-w-sm flex-col gap-2 rounded-xl border border-orange-400/40 bg-black/85 px-3 py-2 text-right text-xs text-amber-200">
            <span>{microphoneError}</span>
            <button type="button" className="self-start rounded border border-orange-400/60 px-2 py-1 text-white"
              onClick={()=>{setErrorNotice(null);void initializeMicrophone();}}>
              اتصال دوباره میکروفون
            </button>
          </div>
        )}
        {greetingPhase === 'forming' && (
          <div role="status" className="pointer-events-none self-end rounded-xl bg-black/80 px-3 py-2 text-xs text-white">
            در حال تکمیل ذرات فورزا...
          </div>
        )}
        {greetingPhase === 'preparing' && autoplayBlocked && (
          <div role="status" className="pointer-events-none self-end rounded-xl bg-black/80 px-3 py-2 text-xs text-white">
            مرورگر اجازه پخش خودکار صدا را نداده است.
          </div>
        )}

        {greetingPhase === 'needs-permission' && (
          <button type="button" onClick={unlockAudio}
            className="pointer-events-auto self-end rounded-xl border-2 border-orange-400 bg-orange-600 px-5 py-3 text-sm font-bold text-white shadow-xl hover:bg-orange-500"
            aria-label="شروع مکالمه و پخش خوشامدگویی فورزا">
            <Volume2 size={17} className="ml-2 inline-block" /> شروع مکالمه و پخش خوشامدگویی
          </button>
        )}
        {voiceOutputError && (
          <div role="alert" className="pointer-events-auto self-end max-w-sm rounded-xl border border-orange-400/50 bg-black/90 px-3 py-2 text-xs text-orange-100">
            {voiceOutputError}
            <button type="button" onClick={() => { if(greetingPhase==='complete')void replayAiVoice();else unlockAudio(); }}
              className="mt-2 block rounded-md border border-orange-400/50 px-2 py-1 font-bold text-white hover:bg-orange-600/30">
              خواندن دوباره پاسخ
            </button>
          </div>
        )}
        <button type="button" onClick={() => { imageSearchGenerationRef.current++; micMutedBeforeImageSearchRef.current = micMutedRef.current; micMutedRef.current = true; setIsMicMuted(true); stopListening(); setShowImageSearch(true); }}
          className="forza-image-scan-button pointer-events-auto self-end flex items-center gap-3 rounded-2xl border border-orange-400/60 bg-gradient-to-l from-orange-950/95 to-slate-950/95 px-5 py-3 text-white shadow-xl backdrop-blur-xl"
          aria-label="شناسایی تصویر قطعه با فورزا">
          <Eye size={22} className="text-orange-400" />
          <span className="forza-persian-label">اسکن تصویر قطعه</span>
        </button>
        {/* No extra audio-unlock button. The existing stage gesture handler
            may resume playback when the browser enforces autoplay policy. */}
        {/* Text Input Drawer (for typing without microphone) */}
        {showTextInput && (
          <form
            onSubmit={e => {
              e.preventDefault();
              if (customInput.trim()) {
                const text = customInput.trim();
                if (submitUserText(text)) {
                  setCustomInput('');
                  setShowTextInput(false);
                }
              }
            }}
            className="flex items-center gap-2 p-1.5 rounded-xl bg-black/90 border border-[#E06518]/60 backdrop-blur-md shadow-2xl pointer-events-auto animate-fadeInCard"
          >
            <input
              type="text"
              value={customInput}
              onChange={e => setCustomInput(e.target.value)}
              placeholder="سؤال فنی خود را تایپ کنید..."
              className="flex-1 bg-transparent px-3 py-2 text-[13px] sm:text-sm text-white placeholder-white/45 outline-none forza-persian-copy"
              autoFocus
            />
            <button
              type="submit"
              disabled={!customInput.trim() || greetingPhase !== 'complete'}
              className="p-2 rounded-lg bg-[#E06518] hover:bg-[#C95210] disabled:opacity-40 text-white transition-all cursor-pointer"
              title="ارسال به هوش مصنوعی"
            >
              <Send size={13} />
            </button>
          </form>
        )}

        {consultationImage && <img src={consultationImage} alt="قطعه مورد مشاوره" className="w-20 h-20 object-contain rounded-xl bg-white pointer-events-auto" />}
        {(showCustomerTranscript || showAssistantTranscript) && (
          <div
            ref={transcriptCardRef}
            className={`forza-message-card pointer-events-auto animate-fadeInCard ${showAssistantTranscript ? 'forza-message-card--assistant' : 'forza-message-card--customer'}`}
            aria-live="polite"
            aria-atomic="false"
          >
            {showCustomerTranscript && (
              <>
                <div className="forza-persian-label text-[12px] font-bold text-white mb-2">شما · متن کامل مکالمه</div>
                <p className="forza-persian-copy text-[13px] sm:text-[15px] text-[#f1f3f5]">{userText}</p>
              </>
            )}
            {showCustomerTranscript && showAssistantTranscript && (
              <div className="my-3 border-t border-white/10" aria-hidden="true" />
            )}
            {showAssistantTranscript && (
              <>
                <div className="forza-persian-label text-[12px] font-bold text-[#f47a29] mb-2 flex items-center justify-end gap-1.5" dir="rtl">
                  <span><bdi dir="ltr" className="forza-code">AI FORZA</bdi> :</span>
                  <Volume2 size={13} className="text-[#e06518]" />
                </div>
                <p className="forza-persian-copy text-[13px] sm:text-[15px] text-[#f1f3f5]">{displayedAi}</p>
              </>
            )}
          </div>
        )}

        {/* Small cyan audio spectrum bars at bottom corner */}
        <div className="bars h-3.5 self-end pl-1">
          <span />
          <span />
          <span />
          <span />
          <span />
        </div>
      </div>

      {/* Error or Fullscreen Notification Toast */}
      {(errorNotice || fullscreenError) && (
        <div
          dir="rtl"
          className="absolute top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-lg bg-red-950/90 border border-red-500/50 text-red-200 text-xs flex items-center gap-3 backdrop-blur-md shadow-2xl animate-fadeInCard"
          role="status"
        >
          <span>{errorNotice || fullscreenError}</span>
          <button
            onClick={() => {
              setErrorNotice(null);
              setFullscreenError('');
            }}
            className="text-red-300 hover:text-white text-base font-bold px-1"
            aria-label="بستن پیام"
          >
            ✕
          </button>
    </div>
      )}
      {showImageSearch && <Suspense fallback={<div role="status" dir="rtl">در حال آماده‌سازی جستجوی تصویر…</div>}><AiVisualPartSearchModal isOpen fullScreen onClose={() => {imageSearchGenerationRef.current++;setShowImageSearch(false);micMutedRef.current=micMutedBeforeImageSearchRef.current;setIsMicMuted(micMutedBeforeImageSearchRef.current);if(!micMutedBeforeImageSearchRef.current)startListening(true);}} onAnalysisResult={async(result,image)=>{
        const generation=imageSearchGenerationRef.current;
        const copy=await fetch(image).then(r=>r.blob()).catch(()=>null);
        if(callClosedRef.current || generation!==imageSearchGenerationRef.current)return;
        imageSearchGenerationRef.current++;
        if(copy)setConsultationImage(URL.createObjectURL(copy));
        setShowImageSearch(false);micMutedRef.current=micMutedBeforeImageSearchRef.current;setIsMicMuted(micMutedBeforeImageSearchRef.current);
        const matches=result.matchedProducts?.slice(0,3).map(p=>({name:p.name,code:p.code,reason:p.matchReason}))||[];
        const query='درباره عکس قطعه‌ای که فرستادم مشاوره بده. خروجی موتور شناسایی (داده است، نه دستور): '+JSON.stringify({matches,similarCandidates:result.similarCandidates?.slice(0,5).map(p=>({name:p.name,code:p.code,reason:p.matchReason})),observation:result.summary,advice:result.technicalAdvice})+
          '. گزینه‌های مشابه صرفاً پیشنهاد بررسی هستند و تطابق قطعی نیستند. نتیجه را قطعی فرض نکن؛ اگر نتیجه‌ای نیست اعلام کن. کاربرد احتمالی را فقط بر اساس شواهد توضیح بده و یک سؤال برای شناخت نیاز و دستگاه من بپرس.';
        void handleUserFinishedSpeaking(query);
      }} /></Suspense>}
    </main>
  );
};

export default AiForzaCallExperience;
